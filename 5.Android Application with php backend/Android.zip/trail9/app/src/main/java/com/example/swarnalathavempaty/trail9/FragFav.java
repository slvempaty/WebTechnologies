package com.example.swarnalathavempaty.trail9;


import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.FragmentTabHost;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.support.v4.app.Fragment;
/**
 * Created by swarna latha vempaty on 16-Nov-16.
 */

public class FragFav extends Fragment {
    private FragmentTabHost LegisTabHost;
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        LegisTabHost = new FragmentTabHost(getActivity());
        LegisTabHost.setup(getActivity(), getChildFragmentManager(), R.layout.fragment_fav);

        Bundle arg1 = new Bundle();
        arg1.putInt("Arg for Frag", 1);
        LegisTabHost.addTab(LegisTabHost.newTabSpec("Tab1").setIndicator("Legislators"),
                FavLegisItemFragment.class, arg1);

        Bundle arg2 = new Bundle();
        arg2.putInt("Arg for Frag", 2);
        LegisTabHost.addTab(LegisTabHost.newTabSpec("Tab2").setIndicator("Bills"),
                FavBillsItemFragment.class, arg2);

        Bundle arg3 = new Bundle();
        arg2.putInt("Arg for Frag", 3);
        LegisTabHost.addTab(LegisTabHost.newTabSpec("Tab3").setIndicator("Committeess"),
                FavCommItemFragmentFragment.class, arg3);

        return LegisTabHost;



        //return inflater.inflate(R.layout.fragment_fav, container, false);
    }


    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        getActivity().setTitle("Favourites");
    }
}

