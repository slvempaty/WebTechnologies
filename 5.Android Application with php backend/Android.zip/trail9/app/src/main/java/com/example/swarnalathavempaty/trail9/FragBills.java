package com.example.swarnalathavempaty.trail9;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.FragmentTabHost;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.support.v4.app.Fragment;



/**
 * Created by swarna latha vempaty on 16-Nov-16.
 */

public class FragBills extends Fragment {
    private FragmentTabHost BillsTabHost;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        BillsTabHost = new FragmentTabHost(getActivity());
        BillsTabHost.setup(getActivity(), getChildFragmentManager(), R.layout.fragment_bills);

        Bundle arg1 = new Bundle();
        arg1.putInt("Arg for Frag1", 1);
        BillsTabHost.addTab(BillsTabHost.newTabSpec("Active").setIndicator("Active Bills"),
                ActiveBillFragment.class, arg1);

        Bundle arg2 = new Bundle();
        arg2.putInt("Arg for Frag2", 2);
        BillsTabHost.addTab(BillsTabHost.newTabSpec("New").setIndicator("New Bills"),
                NewBillFragment.class, arg2);

        return BillsTabHost;
     //  return inflater.inflate(r.layout.fragment_bills, container, false);
    }


    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
         getActivity().setTitle("Bills");
    }
}
