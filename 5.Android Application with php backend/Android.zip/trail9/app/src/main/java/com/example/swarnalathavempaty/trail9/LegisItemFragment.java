package com.example.swarnalathavempaty.trail9;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.StrictMode;
import android.support.v4.app.Fragment;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.LinearLayout;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;

import com.example.swarnalathavempaty.trail9.dummy.DummyContent;
import com.example.swarnalathavempaty.trail9.dummy.DummyContent.DummyItem;
import com.google.gson.Gson;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * A fragment representing a list of Items.
 * <p/>
 * Activities containing this fragment MUST implement the {@link OnListFragmentInteractionListener}
 * interface.
 */
public class LegisItemFragment extends Fragment implements View.OnClickListener {


    private static final String ARG_COLUMN_COUNT = "column-count";

    private int mColumnCount = 4;
    ListView LegisListView;
    private OnListFragmentInteractionListener mListener;
    ArrayList<HashMap<String, String>> LegisList=new ArrayList<HashMap<String, String>>();
    JSONArray Legis;
   Gson gson=new Gson();
    Map<String, Integer> mapIndex = null;
    LinearLayout indexLayout;

    /**
     * Mandatory empty constructor for the fragment manager to instantiate the
     * fragment (e.g. upon screen orientation changes).
     */
    public LegisItemFragment() {
    }


    @SuppressWarnings("unused")
    public static LegisItemFragment newInstance(int columnCount) {
        LegisItemFragment fragment = new LegisItemFragment();
        Bundle args = new Bundle();
        args.putInt(ARG_COLUMN_COUNT, columnCount);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (getArguments() != null) {
            mColumnCount = getArguments().getInt(ARG_COLUMN_COUNT);
           // tabnum=getArguments().getInt("Arg for Frag");
           // ////Log.d("tab",Integer.toString(tabnum));

        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_legisitem_list, container, false);
        LegisListView=(ListView) view.findViewById(R.id.list);
        indexLayout = (LinearLayout) view.findViewById(R.id.side_index_legis);

        new LoadLegisData().execute();


        return view;
    }
    private void sidebar() throws JSONException {
        mapIndex = new LinkedHashMap<String, Integer>();
        for (int i = 0; i < Legis.length(); i++) {
            JSONObject legis = Legis.getJSONObject(i);
            String index = null;
            try {
                index = (String.valueOf(legis.getString("state_name")).substring(0, 1)).toUpperCase();
            } catch (JSONException e) {
                e.printStackTrace();
            }

            if (mapIndex.get(index) == null)
                mapIndex.put(index, i);

        }

    }

    private void updateside() {
        TextView textView;


        List<String> indexList = new ArrayList<String>(mapIndex.keySet());
        for (String index : indexList) {
            textView = (TextView) getActivity().getLayoutInflater().inflate(
                    R.layout.sidebarlegis, null);
            textView.setText(index.toUpperCase());
            textView.setOnClickListener(this);
            indexLayout.addView(textView);
        }
    }

    @Override
    public void onClick(View view) {
        TextView selectedIndex = (TextView) view;
        LegisListView.setSelection(mapIndex.get(selectedIndex.getText()));
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnListFragmentInteractionListener) {
            mListener = (OnListFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnListFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    /**
     * This interface must be implemented by activities that contain this
     * fragment to allow an interaction in this fragment to be communicated
     * to the activity and potentially other fragments contained in that
     * activity.
     * <p/>
     * See the Android Training lesson <a href=
     * "http://developer.android.com/training/basics/fragments/communicating.html"
     * >Communicating with Other Fragments</a> for more information.
     */
    public interface OnListFragmentInteractionListener {

        void onListFragmentInteraction(DummyItem item);
    }

    /// my code

    class LoadLegisData extends AsyncTask<String, String, String> {
        protected String doInBackground(String... args) {

            StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
            StrictMode.setThreadPolicy(policy);
            URL url = null;
            try {
                url = new URL("http://nspsrkt.f32zn4pfwb.us-west-2.elasticbeanstalk.com/trail82.php?legislator=all");
            } catch (MalformedURLException e) {
                e.printStackTrace();
            }
            HttpURLConnection urlConnection = null;
            try {
                urlConnection = (HttpURLConnection) url.openConnection();
            } catch (IOException e) {
                e.printStackTrace();
            }
            try {
                InputStream in = new BufferedInputStream(urlConnection.getInputStream());
                String x = StringConversion(in);
                JSONObject json = new JSONObject(x);
                Legis=json.getJSONArray("results");
Legis=sortJsonArray(Legis);
                //Log.d("json",Legis.toString());
              /*  for(int i=0;i<Legis.length();i++)
                {
                    JSONObject l=Legis.getJSONObject(i);
                    String bio=l.getString("bioguide_id");


                    HashMap<String,String> temp=new HashMap<String, String>();
temp.put("bioguide_id",bio);
                    LegisList.add(temp);
                }*/

                SharedPreferences pref = getActivity().getSharedPreferences("Legis", Context.MODE_PRIVATE);
                SharedPreferences.Editor editor=pref.edit();

                editor.putString("legislist",x);
                editor.commit();

            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            } finally {
                urlConnection.disconnect();
            }
            return null;

        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            /*ListAdapter adapter = new SimpleAdapter(getActivity(),
                    LegisList,
                    r.layout.fragment_legisitem,
                    new String[] { "bioguide_id" },
                    new int[] { r.id.secondLine });*/

            LegisListView.setAdapter(new LegisCustom(getActivity(),R.layout.fragment_legisitem,Legis));
            try {
                sidebar();
            } catch (JSONException e) {
                e.printStackTrace();
            }
            updateside();
        }
        public JSONArray sortJsonArray(JSONArray array) {
            List<JSONObject> jsonarray = new ArrayList<JSONObject>();
            try {
            for (int i = 0; i < array.length(); i++) {

                jsonarray.add(array.getJSONObject(i));
            }

            Collections.sort(jsonarray, new Comparator<JSONObject>() {
                @Override
                public int compare(JSONObject lhs, JSONObject rhs) {
                    String lel="";
                    String rel="";

                    try {
                         lel = lhs.getString("state_name");

                     rel = rhs.getString("state_name");

                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                    return lel.compareTo(rel);
                }
            });
             }catch (JSONException e) {
                    e.printStackTrace();
                }

            return new JSONArray(jsonarray);
        }
    }


    public static String StringConversion(InputStream Input)
            throws IOException {
        if (Input != null) {
            StringBuilder sb = new StringBuilder();
            String line;

            try {
                BufferedReader r1 = new BufferedReader(new InputStreamReader(
                        Input, "UTF-8"));
                while ((line = r1.readLine()) != null) {
                    sb.append(line).append("\n");
                }
            } finally {
                Input.close();
            }
            return sb.toString();
        } else {
            return "";
        }

    }

}
