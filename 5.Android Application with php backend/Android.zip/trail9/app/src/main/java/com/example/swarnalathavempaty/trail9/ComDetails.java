package com.example.swarnalathavempaty.trail9;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class ComDetails extends AppCompatActivity {
    Boolean isFav;
    ImageView favStar;
    ArrayList<String> fav =new ArrayList<String>();
    String Comm="";
    Gson gson=new Gson();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTitle("Committee Info");
        setContentView(R.layout.activity_com_details);
        Intent in = getIntent();
        Bundle b = in.getExtras();
        if (b != null) {



            String name = (String) b.get("name");
            String parent_committee_id = (String) b.get("parent_committee_id");
            String chamber = (String) b.get("chamber");
            String contact = (String) b.get("contact");
            String office = (String) b.get("office");
             Comm = (String) b.get("Comm");

            //////Log.d("comm",name);

            TextView nameview = (TextView) findViewById(R.id.commidvalue);
            nameview.setText(Comm);

            TextView emailview = (TextView) findViewById(R.id.commnamevalue);
            emailview.setText(name);
if(chamber.compareTo("House")==0){
            Picasso.with(this)
                    .load(R.drawable.h).placeholder(R.drawable.ic_menu_camera)
                    .error(R.drawable.ic_menu_camera)
                    .into((ImageView) findViewById(R.id.commchambericon));}
            else{
    Picasso.with(this)
            .load(R.drawable.s).placeholder(R.drawable.ic_menu_camera)
            .error(R.drawable.ic_menu_camera)
            .into((ImageView) findViewById(R.id.commchambericon));
            }

            TextView chamberview = (TextView) findViewById(R.id.commchambervalue);
            chamberview.setText(chamber);
            TextView phoneview = (TextView) findViewById(R.id.commparentvalue);
            phoneview.setText(parent_committee_id);
            TextView startview = (TextView) findViewById(R.id.commcontactvalue);
            startview.setText(contact);
            TextView endview = (TextView) findViewById(R.id.commofficevalue);
            endview.setText(office);

            favStar=(ImageView) findViewById(R.id.commfavstar);

            Picasso.with(this)
                    .load(R.drawable.star).placeholder(R.drawable.star)
                    .error(R.drawable.star)
                    .into(favStar);

        }
        isFav=false;

        SharedPreferences pref = getSharedPreferences("Fav", Context.MODE_PRIVATE);
        String jsonComm=pref.getString("Comm",null);
        //   ////Log.d("legis",jsonLegis);
        if(jsonComm!=null) {
            //  ////Log.d("inside","not null");
            gson = new Gson();
            fav = gson.fromJson(jsonComm, new TypeToken<ArrayList<String>>() {
            }.getType());
            for (int i = 0; i < fav.size(); i++) {
                // ////Log.d("favLegis",fav.get(i));
                //////Log.d("legisbio",bio);
                if (fav.get(i).compareTo(Comm) == 0) {
                 //   ////Log.d("legis","setting");
                    favStar=(ImageView) findViewById(R.id.commfavstar);
                    Picasso.with(this)
                            .load(R.drawable.filled).placeholder(R.drawable.filled)
                            .error(R.drawable.filled)
                            .into(favStar);
                    isFav = true;
                    break;
                }
            }


        }
        favStar=(ImageView) findViewById(R.id.commfavstar);
        favStar.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                //v.getId() will give you the image id
                changeImage();
              //  ////Log.d("legis","clicked");
            }



        });}
    public void changeImage(){

        SharedPreferences pref=getSharedPreferences("Fav",Context.MODE_PRIVATE);
        SharedPreferences.Editor editor=pref.edit();
        if(isFav){
            Picasso.with(this)
                    .load(R.drawable.star).placeholder(R.drawable.star)
                    .error(R.drawable.star)
                    .into(favStar);
            fav.remove(Comm);
            isFav=false;


        }
        else{
            Picasso.with(this)
                    .load(R.drawable.filled).placeholder(R.drawable.filled)
                    .error(R.drawable.filled)
                    .into(favStar);
            fav.add(Comm);
            isFav=true;
        }
        String json=gson.toJson(fav);
        editor.putString("Comm",json);
        editor.commit();
       // ////Log.d("Comm",json);
    }
}

