package com.example.swarnalathavempaty.trail9;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class BillDetails extends AppCompatActivity {
    Boolean isFav;
    ImageView favStar;
    ArrayList<String> fav =new ArrayList<String>();
    String bill_id="";
    Gson gson=new Gson();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTitle("Bill Info");
        setContentView(R.layout.activity_bill_details);
        Intent in=getIntent();
        Bundle b=in.getExtras();
        if(b!=null)
        {



             bill_id =(String) b.get("bill");
            String title=(String) b.get("title");
            String intro=(String) b.get("intro");
            String billtype=(String) b.get("billtype");
            String sponsor=(String) b.get("sponsor");
            String chamber=(String) b.get("chamber");
            String curl=(String) b.get("curl");
            String vstatus=(String) b.get("vstatus");
            String pdfurl=(String) b.get("pdfurl");
            String status=(String) b.get("status");


            TextView nameview = (TextView)findViewById(R.id.billidvalue);
            nameview.setText(bill_id);

            TextView emailview = (TextView)findViewById(R.id.titlevalue);
            emailview.setText(title);
            TextView chamberview = (TextView)findViewById(R.id.billchambervalue);
            chamberview.setText(chamber);
            TextView phoneview = (TextView)findViewById(R.id.billintrovalue);
            phoneview.setText(intro);
            TextView startview = (TextView)findViewById(R.id.billtypevalue);
            startview.setText(billtype);
            TextView endview = (TextView)findViewById(R.id.sponsorvalue);
            endview.setText(sponsor);
            TextView officeview = (TextView)findViewById(R.id.billurlvalue);
            officeview.setText(curl);
            TextView stateview = (TextView)findViewById(R.id.billversionstatusvalue);
            stateview.setText(vstatus);
            TextView faxview = (TextView)findViewById(R.id.billlurlvalue);
            faxview.setText(pdfurl);
            TextView birthdayview = (TextView)findViewById(R.id.billstatusvalue);
            birthdayview.setText(status);
            favStar=(ImageView) findViewById(R.id.billfavstar);
            Picasso.with(this)
                    .load(R.drawable.star).placeholder(R.drawable.star)
                    .error(R.drawable.star)
                    .into(favStar);


        }

        isFav=false;

        SharedPreferences pref = getSharedPreferences("Fav", Context.MODE_PRIVATE);
        String jsonBills=pref.getString("Bills",null);
        //   ////Log.d("legis",jsonLegis);
        if(jsonBills!=null) {
            //  ////Log.d("inside","not null");
            gson = new Gson();
            fav = gson.fromJson(jsonBills, new TypeToken<ArrayList<String>>() {
            }.getType());
            for (int i = 0; i < fav.size(); i++) {
                // ////Log.d("favLegis",fav.get(i));
                //////Log.d("legisbio",bio);
                if (fav.get(i).compareTo(bill_id) == 0) {
                   // ////Log.d("legis","setting");
                    Picasso.with(this)
                            .load(R.drawable.filled).placeholder(R.drawable.filled)
                            .error(R.drawable.filled)
                            .into(favStar);
                    isFav = true;
                    break;
                }
            }


        }
        favStar.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                //v.getId() will give you the image id
                changeImage();
              //  ////Log.d("legis","clicked");
            }



        });}
    public void changeImage(){

        SharedPreferences pref=getSharedPreferences("Fav",Context.MODE_PRIVATE);
        SharedPreferences.Editor editor=pref.edit();
        if(isFav){
            Picasso.with(this)
                    .load(R.drawable.star).placeholder(R.drawable.star)
                    .error(R.drawable.star)
                    .into(favStar);
            fav.remove(bill_id);
            isFav=false;


        }
        else{
            Picasso.with(this)
                    .load(R.drawable.filled).placeholder(R.drawable.filled)
                    .error(R.drawable.filled)
                    .into(favStar);
            fav.add(bill_id);
            isFav=true;
        }
        String json=gson.toJson(fav);
        editor.putString("Bills",json);
        editor.commit();

       // ////Log.d("legis",json);

    }
}
