package com.example.swarnalathavempaty.trail9;


import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.FragmentTabHost;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.support.v4.app.Fragment;
/**
 * Created by swarna latha vempaty on 16-Nov-16.
 */

public class FragComm extends Fragment {
    private FragmentTabHost CommTabHost;
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {






        CommTabHost = new FragmentTabHost(getActivity());
        CommTabHost.setup(getActivity(), getChildFragmentManager(), R.layout.fragment_comm);

        Bundle arg1 = new Bundle();
        arg1.putInt("Arg for Frag1", 1);
        CommTabHost.addTab(CommTabHost.newTabSpec("House").setIndicator("House"),
                CommHouseFragment.class, arg1);

        Bundle arg2 = new Bundle();
        arg2.putInt("Arg for Frag2", 2);
        CommTabHost.addTab(CommTabHost.newTabSpec("Senate").setIndicator("Senate"),
                CommSenateFragment.class, arg2);

        Bundle arg3 = new Bundle();
        arg2.putInt("Arg for Frag3", 3);
        CommTabHost.addTab(CommTabHost.newTabSpec("Joint").setIndicator("Joint"),
                CommJointFragment.class, arg3);

        return CommTabHost;
        // return inflater.inflate(r.layout.fragment_comm, container, false);
    }


    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
       getActivity().setTitle("Committees");
    }
}

