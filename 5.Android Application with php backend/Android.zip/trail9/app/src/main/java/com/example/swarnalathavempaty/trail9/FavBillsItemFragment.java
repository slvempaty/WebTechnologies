package com.example.swarnalathavempaty.trail9;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;

import com.example.swarnalathavempaty.trail9.dummy.DummyContent;
import com.example.swarnalathavempaty.trail9.dummy.DummyContent.DummyItem;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import static android.R.attr.x;


public class FavBillsItemFragment extends Fragment {

    // TODO: Customize parameter argument names
    private static final String ARG_COLUMN_COUNT = "column-count";
    // TODO: Customize parameters
    private int mColumnCount = 1;

    ListView FavBillsListView;
    ArrayList<HashMap<String, String>> FavBillsList=new ArrayList<HashMap<String, String>>();
    ArrayList<HashMap<String, String>> newb =new ArrayList<HashMap<String, String>>();
 ArrayList<HashMap<String, String>> active =new ArrayList<HashMap<String, String>>();
JSONArray activebi= new JSONArray();
 JSONArray newbi=new JSONArray();
    JSONArray Favactive=new JSONArray();//full bills details of bills that are in FavBillsList


    Gson gson=new Gson();
    ArrayList<String> fav =new ArrayList<String>();


    /**
     * Mandatory empty constructor for the fragment manager to instantiate the
     * fragment (e.g. upon screen orientation changes).
     */
    public FavBillsItemFragment() {
    }

    // TODO: Customize parameter initialization
    @SuppressWarnings("unused")
    public static FavBillsItemFragment newInstance(int columnCount) {
        FavBillsItemFragment fragment = new FavBillsItemFragment();
        Bundle args = new Bundle();
        args.putInt(ARG_COLUMN_COUNT, columnCount);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (getArguments() != null) {
            mColumnCount = getArguments().getInt(ARG_COLUMN_COUNT);
        }
    }

    @Override
    public void onResume(){
        super.onResume();
        try {
            LoadFavBillsdata();// Set the adapter
        } catch (JSONException e) {
            e.printStackTrace();
        }


        adapterfunc();

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_favbillsitem_list, container, false);

        FavBillsListView=(ListView) view.findViewById(R.id.favbillslist);

        try {
            LoadFavBillsdata();// Set the adapter
        } catch (JSONException e) {
            e.printStackTrace();
        }


        adapterfunc();

        return view;
    }

    private void adapterfunc(){
        ListAdapter adapter = new SimpleAdapter(getActivity(),
                FavBillsList,
                R.layout.fragment_favbillsitem,
                new String[] { "bill_id","title","intro" },
                new int[] { R.id.favbillid,R.id.favbilltitle,R.id.favbilldate });
        FavBillsListView.setAdapter(adapter);

        FavBillsListView.setOnItemClickListener(new AdapterView.OnItemClickListener()
        {
            @Override
            public void onItemClick(AdapterView<?> parent, View view,
                                    int position, long id) {

                Intent in = new Intent(getActivity(), BillDetails.class);

                in.putExtra("bill", FavBillsList.get(position).get("bill_id"));

                String clicked = FavBillsList.get(position).get("bill_id");

                boolean found = false;
                for (int i = 0; i < newbi.length(); i++) {

                    JSONObject l = null;
                    try {
                        l = newbi.getJSONObject(i);

                        if (clicked.equals(l.getString("bill_id"))) {

                            String title = "N.A";
                            if (l.has("official_title")) {

                                title = l.getString("official_title");
                            }

                            String introdate = "N.A";
                            if (l.has("introduced_on")) {

                                l.getString("introduced_on");
                            }

                            String billtype = "N.A";
                            if (l.has("bill_type")) {

                                billtype = l.getString("bill_type");
                            }

                            String sponsor = l.getJSONObject("sponsor").getString("title") + "." + l.getJSONObject("sponsor").getString("last_name") + "," + l.getJSONObject("sponsor").getString("first_name");
                            ////Log.d("spo1",sponsor);

                            String chamber = "N.A";
                            if (l.has("chamber")) {

                                l.getString("chamber");
                            }
                            String curl = l.getJSONObject("urls").getString("congress");
                            ////Log.d("spo1",curl);
                            String vstatus = "N.A";
                            if (l.has("last_version") && l.getJSONObject("last_version").has("version_name")) {
                                vstatus = l.getJSONObject("last_version").getString("version_name");
                            }
                            ////Log.d("spo1",vstatus);
                            String pdfurl = "N.A";
                            if (l.getJSONObject("urls").has("pdf")) {
                                pdfurl = l.getJSONObject("urls").getString("pdf");
                            }


                            in.putExtra("title", title);

                            in.putExtra("billtype", billtype);
                            in.putExtra("sponsor", sponsor);
                            in.putExtra("chamber", chamber);
                            in.putExtra("intro", introdate);
                            in.putExtra("curl", curl);
                            in.putExtra("vstatus", vstatus);
                            in.putExtra("pdfurl", pdfurl);
                            in.putExtra("status", "Active");
                            found = true;
                            break;

                        }


                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
                if(found==false){
                    for (int i = 0; i < activebi.length(); i++) {

                        JSONObject l = null;
                        try {
                            l = activebi.getJSONObject(i);

                            if (clicked.equals(l.getString("bill_id"))) {

                                String title ="N.A";
                                if (l.has("official_title")) {

                                    title  = l.getString("official_title");}

                                String introdate ="N.A";
                                if (l.has("introduced_on")) {

                                    l.getString("introduced_on");}

                                String billtype ="N.A";
                                if (l.has("bill_type")) {

                                    billtype= l.getString("bill_type");}

                                String sponsor = l.getJSONObject("sponsor").getString("title") + "." + l.getJSONObject("sponsor").getString("last_name") + "," + l.getJSONObject("sponsor").getString("first_name");
                                ////Log.d("spo1",sponsor);

                                String chamber ="N.A";
                                if (l.has("chamber")) {

                                    l.getString("chamber");}
                                String curl = l.getJSONObject("urls").getString("congress");
                                ////Log.d("spo1",curl);
                                String vstatus="N.A";
                                if (l.has("last_version") && l.getJSONObject("last_version").has("version_name") ) {
                                    vstatus = l.getJSONObject("last_version").getString("version_name");
                                }
                                ////Log.d("spo1",vstatus);
                                String pdfurl = "N.A";
                                if (l.getJSONObject("urls").has("pdf")) {
                                    pdfurl = l.getJSONObject("urls").getString("pdf");
                                }


                                in.putExtra("title", title);

                                in.putExtra("billtype", billtype);
                                in.putExtra("sponsor", sponsor);
                                in.putExtra("chamber", chamber);
                                in.putExtra("intro", introdate);
                                in.putExtra("curl", curl);
                                in.putExtra("vstatus", vstatus);
                                in.putExtra("pdfurl", pdfurl);
                                in.putExtra("status", "Active");
                                found=true;
                                break;

                            }


                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }}
                getActivity().startActivity(in);
            }});


    }



    private void LoadFavBillsdata() throws JSONException {
        SharedPreferences pref = getActivity().getSharedPreferences("Bills", Context.MODE_PRIVATE);
        String jsonBills = pref.getString("Active", null);
String jsonBillsfull=pref.getString("Activeb",null);
String jsonNewBills=pref.getString("Newones", null);
  String jsonnewBillsfull=pref.getString("Newonesli",null);
        FavBillsList=new ArrayList<HashMap<String, String>>();
      //  Favactive=new JSONArray();
        SharedPreferences pref1 = getActivity().getSharedPreferences("Fav", Context.MODE_PRIVATE);
        String jsonFavBills = pref1.getString("Bills", null);

////Log.d("inside1",jsonBillsfull);
       // ////Log.d("inside1",jsonFavBills);

        if (jsonBills != null && jsonFavBills != null && jsonBillsfull!= null) {

            active = gson.fromJson(jsonBills, new TypeToken<ArrayList<HashMap<String, String>>>() {
            }.getType());
            JSONObject json = new JSONObject(jsonBillsfull);
            activebi=json.getJSONArray("results");

            fav = gson.fromJson(jsonFavBills, new TypeToken<ArrayList<String>>() {
            }.getType());


            for (int i = 0; i < fav.size(); i++) {
                for(int j=0;j<active.size();j++)
                {
                    if(fav.get(i).compareTo(active.get(j).get("bill_id")) == 0){
                       // ////Log.d("inside","hurray");
                        FavBillsList.add(active.get(j));
                     //   Favactive.put(activebi.get(j));
                        break;
                    }
                }
            }
        }
        if (jsonNewBills != null && jsonFavBills != null && jsonnewBillsfull !=null) {

            newb = gson.fromJson(jsonNewBills, new TypeToken<ArrayList<HashMap<String, String>>>() {
            }.getType());

            JSONObject json = new JSONObject(jsonnewBillsfull);


            newbi=json.getJSONArray("results");

            fav = gson.fromJson(jsonFavBills, new TypeToken<ArrayList<String>>() {
            }.getType());


            for (int i = 0; i < fav.size(); i++) {
                for(int j=0;j<newb.size();j++)
                {
                    if(fav.get(i).compareTo(newb.get(j).get("bill_id")) == 0){
                        // ////Log.d("inside","hurray");
                        FavBillsList.add(newb.get(j));
                    //    Favactive.put(newbi.get(j));
                        break;
                    }
                }
            }
        }
FavBillsList=sortJsonArray(FavBillsList);
    }
    public ArrayList<HashMap<String,String>> sortJsonArray(ArrayList<HashMap<String,String>> array) {
        List<JSONObject> jsonarray = new ArrayList<JSONObject>();


        Collections.sort(array, new Comparator<HashMap<String,String>>() {
            @Override
            public int compare(HashMap<String,String> lhs, HashMap<String,String> rhs) {
                String lel="";
                String rel="";


                lel = lhs.get("intro");

                rel = rhs.get("intro");

                SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
                Date convertedDate1 = new Date();
                Date convertedDate2 = new Date();

                try {
                    convertedDate1 = dateFormat.parse(lel);
                    convertedDate2 = dateFormat.parse(rel);
                    //Log.d("date1",convertedDate1.toString());
                    //Log.d("date2",convertedDate2.toString());

                } catch (ParseException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }



                return convertedDate2.compareTo(convertedDate1);
            }
        });

        return new ArrayList<HashMap<String,String>>(array);
    }

}
