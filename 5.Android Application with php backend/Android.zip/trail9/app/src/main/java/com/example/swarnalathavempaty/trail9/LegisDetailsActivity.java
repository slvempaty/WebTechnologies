package com.example.swarnalathavempaty.trail9;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;

public class LegisDetailsActivity extends AppCompatActivity {
    Boolean isFav;
    ImageView favStar;
    ArrayList<String> fav =new ArrayList<String>();
    String bio="";
    Gson gson=new Gson();
    String fb="N.A";
    String tw="N.A";
    String wb="N.A";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTitle("Legislator Info");
        Intent in=getIntent();
        Bundle b=in.getExtras();
        setContentView(R.layout.activity_legis_details);


        if(b!=null)
        {
 bio=(String) b.get("bio");
            String name =(String) b.get("name");
            String photo=(String) b.get("photo");
            String party=(String) b.get("party");
            fb=(String) b.get("fb");
            tw=(String) b.get("tw");
            wb=(String) b.get("wb");
            String email=(String) b.get("email");
            String chamber=(String) b.get("chamber");
            String phone=(String) b.get("phone");
            String start=(String) b.get("start");
            String end=(String) b.get("end");
            String office=(String) b.get("office");
            String state=(String) b.get("state");
            String fax=(String) b.get("fax");
            String birthday=(String) b.get("birthday");
int progbar= b.getInt("pb");


            TextProgressBar pb=(TextProgressBar) findViewById(R.id.termvalue);
pb.setProgressDrawable(getResources().getDrawable(R.drawable.custom_pb));
           // Drawable draw=getDrawable(R.drawable.custom_pb);
          //  pb.setProgressDrawable(draw);
            pb.setProgress(progbar);
            pb.setText(Integer.toString(progbar)+"%");

         //   TextView pbtext=(TextView)findViewById(R.id.perctext);
         //   pbtext.setText(progbar+"%");

            ImageView website=(ImageView) findViewById(R.id.website);
            ImageView fbv=(ImageView) findViewById(R.id.fb);
            ImageView twv =(ImageView) findViewById(R.id.tw);

            website.setOnClickListener(new View.OnClickListener(){
                public void onClick(View v){
                    if(wb.compareTo("N.A")==0){
                        Toast.makeText(getApplicationContext(), "No website Link", Toast.LENGTH_SHORT).show();
                    }
                   else { Intent intent = new Intent();
                    intent.setAction(Intent.ACTION_VIEW);
                    intent.addCategory(Intent.CATEGORY_BROWSABLE);
                    intent.setData(Uri.parse(wb));
                    startActivity(intent);}
                }
            });

            fbv.setOnClickListener(new View.OnClickListener(){
                public void onClick(View v){
                    if(fb.compareTo("N.A")==0){
                        Toast.makeText(getApplicationContext(), "No FB page", Toast.LENGTH_SHORT).show();

                    }
                    else { Intent intent = new Intent();
                        intent.setAction(Intent.ACTION_VIEW);
                        intent.addCategory(Intent.CATEGORY_BROWSABLE);
                        intent.setData(Uri.parse("https://facebook.com/" + fb));
                        startActivity(intent);}
                }
            });

            twv.setOnClickListener(new View.OnClickListener(){
                public void onClick(View v){
                    if(tw.compareTo("N.A")==0){
                        Toast.makeText(getApplicationContext(), "No twitter page", Toast.LENGTH_SHORT).show();

                    }
                    else { Intent intent = new Intent();
                        intent.setAction(Intent.ACTION_VIEW);
                        intent.addCategory(Intent.CATEGORY_BROWSABLE);
                        intent.setData(Uri.parse("https://twitter.com/" +tw ));
                        startActivity(intent);}
                }
            });




            TextView nameview = (TextView)findViewById(R.id.namevalue);
            nameview.setText(name);
            Picasso.with(this)
                    .load(photo).placeholder(R.drawable.ic_menu_camera)
                    .error(android.R.drawable.ic_menu_camera)
                    .resize(150,150)
                    .into((ImageView) findViewById(R.id.legisimage));
            TextView partyview= (TextView)findViewById(R.id.partyname);
            //Log.d("abc",party);
            if(party.compareTo("R") ==0){

                partyview.setText("Repulican");

                Picasso.with(this)
                        .load(R.drawable.r).placeholder(R.drawable.r)
                        .error(R.drawable.r)
                        .resize(150,150)
                        .into((ImageView) findViewById(R.id.partyicon));


            }else if(party.compareTo("D") ==0){

                partyview.setText("Democrat");

                Picasso.with(this)
                        .load(R.drawable.d).placeholder(R.drawable.d)
                        .error(R.drawable.d)
                        .resize(150,150)
                        .into((ImageView) findViewById(R.id.partyicon));


            }else{
                partyview.setText("Independent");

            }

           // TextView party = (TextView)findViewById(R.id.);
           // nameview.setText(name);
            TextView emailview = (TextView)findViewById(R.id.emailvalue);
            emailview.setText(email);
            TextView chamberview = (TextView)findViewById(R.id.chambervalue);
            chamberview.setText(chamber);
            TextView phoneview = (TextView)findViewById(R.id.contactvalue);
            phoneview.setText(phone);
            TextView startview = (TextView)findViewById(R.id.startvalue);
            startview.setText(start);
            TextView endview = (TextView)findViewById(R.id.endvalue);
            endview.setText(end);
            TextView officeview = (TextView)findViewById(R.id.officevalue);
            officeview.setText(office);
            TextView stateview = (TextView)findViewById(R.id.statevalue);
            stateview.setText(state);
            TextView faxview = (TextView)findViewById(R.id.faxvalue);
            faxview.setText(fax);
            TextView birthdayview = (TextView)findViewById(R.id.birthvalue);
            birthdayview.setText(birthday);
            favStar=(ImageView) findViewById(R.id.legisfavstar);
            Picasso.with(this)
                    .load(R.drawable.star).placeholder(R.drawable.star)
                    .error(R.drawable.star)
                    .into(favStar);
}
isFav=false;

        SharedPreferences pref = getSharedPreferences("Fav", Context.MODE_PRIVATE);
String jsonLegis=pref.getString("Legis",null);
     //   ////Log.d("legis",jsonLegis);
        if(jsonLegis!=null) {
          //  ////Log.d("inside","not null");
            gson = new Gson();
            fav = gson.fromJson(jsonLegis, new TypeToken<ArrayList<String>>() {
            }.getType());
            for (int i = 0; i < fav.size(); i++) {
               // ////Log.d("favLegis",fav.get(i));
                //////Log.d("legisbio",bio);
                if (fav.get(i).compareTo(bio) == 0) {
                    ////Log.d("legis","setting");
                    Picasso.with(this)
                            .load(R.drawable.filled).placeholder(R.drawable.filled)
                            .error(R.drawable.filled)
                            .into(favStar);
                    isFav = true;
                    break;
                }
            }


        }
        favStar.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                //v.getId() will give you the image id
               changeImage();
                ////Log.d("legis","clicked");
                }



        });}
    public void changeImage(){

        SharedPreferences pref=getSharedPreferences("Fav",Context.MODE_PRIVATE);
        SharedPreferences.Editor editor=pref.edit();
        if(isFav){
            Picasso.with(this)
                    .load(R.drawable.star).placeholder(R.drawable.star)
                    .error(R.drawable.star)
                    .into(favStar);
            fav.remove(bio);
isFav=false;


        }
        else{
            Picasso.with(this)
                    .load(R.drawable.filled).placeholder(R.drawable.filled)
                    .error(R.drawable.filled)
                    .into(favStar);
            fav.add(bio);
            isFav=true;
        }
        String json=gson.toJson(fav);
        editor.putString("Legis",json);
        editor.commit();
        ////Log.d("legis",json);
       }
}
