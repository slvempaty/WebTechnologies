package com.example.swarnalathavempaty.trail9;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.StrictMode;
import android.support.v4.app.Fragment;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.content.SharedPreferences;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.Toast;

import com.example.swarnalathavempaty.trail9.dummy.DummyContent;
import com.example.swarnalathavempaty.trail9.dummy.DummyContent.DummyItem;
import com.google.gson.Gson;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

/**
 * A fragment representing a list of Items.
 * <p/>
 * Activities containing this fragment MUST implement the {@link //OnListFragmentInteractionListener}
 * interface.
 */
public class ActiveBillFragment extends Fragment {

    // TODO: Customize parameter argument names
    private static final String ARG_COLUMN_COUNT = "column-count";
    // TODO: Customize parameters
    private int mColumnCount = 1;
    ListView ActiveBillsListView;
    private OnBillsListFragmentInteractionListener mListener;
    ArrayList<HashMap<String, String>> ActiveBillsList=new ArrayList<HashMap<String, String>>();
    JSONArray Legis;
    Gson gson=new Gson();


    /**
     * Mandatory empty constructor for the fragment manager to instantiate the
     * fragment (e.g. upon screen orientation changes).
     */
    public ActiveBillFragment() {
    }

    // TODO: Customize parameter initialization
    @SuppressWarnings("unused")
    public static ActiveBillFragment newInstance(int columnCount) {
        ActiveBillFragment fragment = new ActiveBillFragment();
        Bundle args = new Bundle();
        args.putInt(ARG_COLUMN_COUNT, columnCount);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (getArguments() != null) {
            mColumnCount = getArguments().getInt(ARG_COLUMN_COUNT);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_activebill_list, container, false);

        // Set the adapter
        ActiveBillsListView=(ListView) view.findViewById(R.id.activebilllist);

        new LoadActiveBillsData().execute();
        return view;
    }


    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnBillsListFragmentInteractionListener) {
            mListener = (OnBillsListFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnListFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    /**
     * This interface must be implemented by activities that contain this
     * fragment to allow an interaction in this fragment to be communicated
     * to the activity and potentially other fragments contained in that
     * activity.
     * <p/>
     * See the Android Training lesson <a href=
     * "http://developer.android.com/training/basics/fragments/communicating.html"
     * >Communicating with Other Fragments</a> for more information.
     */
    public interface OnBillsListFragmentInteractionListener {
        // TODO: Update argument type and name
        void OnBillsListFragmentInteraction(DummyItem item);
    }

    class LoadActiveBillsData extends AsyncTask<String, String, String> {
        protected String doInBackground(String... args) {

            StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
            StrictMode.setThreadPolicy(policy);
            URL url = null;
            try {
                url = new URL("http://nspsrkt.f32zn4pfwb.us-west-2.elasticbeanstalk.com/trail82.php?BillDataActive=all");
            } catch (MalformedURLException e) {
                e.printStackTrace();
            }
            HttpURLConnection urlConnection = null;
            try {
                urlConnection = (HttpURLConnection) url.openConnection();
            } catch (IOException e) {
                e.printStackTrace();
            }
            try {
                InputStream in = new BufferedInputStream(urlConnection.getInputStream());
                String x = StringConversion(in);
                JSONObject json = new JSONObject(x);


                 Legis=json.getJSONArray("results");


                ActiveBillsList=new ArrayList<HashMap<String, String>>();

                for(int i=0;i<Legis.length();i++)
                {
                    JSONObject l=Legis.getJSONObject(i);
                    String bill=l.getString("bill_id");
                    String title=l.getString("official_title");
                    String introdate = l.getString("introduced_on");
                    HashMap<String, String> temp = new HashMap<String, String>();
                    temp.put("bill_id", bill);
                    temp.put("title", title);
                    temp.put("intro", introdate);
                    ActiveBillsList.add(temp);

                }

                ActiveBillsList =sortJsonArray(ActiveBillsList);
                //Log.d("bills",ActiveBillsList.toString());

                SharedPreferences pref = getActivity().getSharedPreferences("Bills", Context.MODE_PRIVATE);
                SharedPreferences.Editor editor=pref.edit();
                String billsjson=gson.toJson(ActiveBillsList);
                editor.putString("Active",billsjson);
                editor.putString("Activeb",x);
                editor.commit();


            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            } finally {
                urlConnection.disconnect();
            }
            return null;

        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            ListAdapter adapter = new SimpleAdapter(getActivity(),
                    ActiveBillsList,
                    R.layout.fragment_activebill,
                    new String[] { "bill_id","title","intro" },
                    new int[] { R.id.activebillid,R.id.activebilltitle,R.id.activebilldate });

            ActiveBillsListView.setAdapter(adapter);

            ActiveBillsListView.setOnItemClickListener(new AdapterView.OnItemClickListener()
            {
                @Override
                public void onItemClick(AdapterView<?> parent, View view,
                                        int position, long id) {

                    Intent in=new Intent(getActivity(),BillDetails.class);

                    in.putExtra("bill",ActiveBillsList.get(position).get("bill_id"));

                    String clicked=ActiveBillsList.get(position).get("bill_id");

                    for (int i = 0; i < Legis.length(); i++) {
                        JSONObject l = null;
                        try {
                            l = Legis.getJSONObject(i);

                            if (clicked.equals(l.getString("bill_id"))) {

                                String title ="N.A";
                                if (l.has("official_title")) {

                                    title  = l.getString("official_title");}

                                String introdate ="N.A";
                                if (l.has("introduced_on")) {

                                    l.getString("introduced_on");}

                                String billtype ="N.A";
                                if (l.has("bill_type")) {

                                    billtype= l.getString("bill_type");}

                                String sponsor = l.getJSONObject("sponsor").getString("title") + "." + l.getJSONObject("sponsor").getString("last_name") + "," + l.getJSONObject("sponsor").getString("first_name");
                               ////Log.d("spo1",sponsor);

                                String chamber ="N.A";
                                if (l.has("chamber")) {

                                    l.getString("chamber");}
                                String curl = l.getJSONObject("urls").getString("congress");
                                ////Log.d("spo1",curl);
                                String vstatus="N.A";
                                if (l.has("last_version") && l.getJSONObject("last_version").has("version_name") ) {
                                     vstatus = l.getJSONObject("last_version").getString("version_name");
                                }
                                ////Log.d("spo1",vstatus);
                                String pdfurl = "N.A";
                                if (l.getJSONObject("urls").has("pdf")) {
                                    pdfurl = l.getJSONObject("urls").getString("pdf");
                                }


                                in.putExtra("title", title);

                                in.putExtra("billtype", billtype);
                                in.putExtra("sponsor", sponsor);
                                in.putExtra("chamber", chamber);
                                in.putExtra("intro", introdate);
                                in.putExtra("curl", curl);
                                in.putExtra("vstatus", vstatus);
                                in.putExtra("pdfurl", pdfurl);
                                in.putExtra("status", "Active");
break;

                            }


                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }
                    getActivity().startActivity(in);
                }});
        }

        public ArrayList<HashMap<String,String>> sortJsonArray(ArrayList<HashMap<String,String>> array) {
            List<JSONObject> jsonarray = new ArrayList<JSONObject>();


                Collections.sort(array, new Comparator<HashMap<String,String>>() {
                    @Override
                    public int compare(HashMap<String,String> lhs, HashMap<String,String> rhs) {
                        String lel="";
                        String rel="";


                            lel = lhs.get("intro");

                            rel = rhs.get("intro");

                       SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
                        Date convertedDate1 = new Date();
                        Date convertedDate2 = new Date();

                        try {
                            convertedDate1 = dateFormat.parse(lel);
                            convertedDate2 = dateFormat.parse(rel);
                          //  //Log.d("date1",convertedDate1.toString());
                           // //Log.d("date2",convertedDate2.toString());

                        } catch (ParseException e) {
                            // TODO Auto-generated catch block
                            e.printStackTrace();
                        }



                        return convertedDate2.compareTo(convertedDate1);
                    }
                });

            return new ArrayList<HashMap<String,String>>(array);
        }
    }




    public static String StringConversion(InputStream Input)
            throws IOException {
        if (Input != null) {
            StringBuilder sb = new StringBuilder();
            String line;

            try {
                BufferedReader r1 = new BufferedReader(new InputStreamReader(
                        Input, "UTF-8"));
                while ((line = r1.readLine()) != null) {
                    sb.append(line).append("\n");
                }
            } finally {
                Input.close();
            }
            return sb.toString();
        } else {
            return "";
        }

    }

}
