package com.example.swarnalathavempaty.trail9;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import com.example.swarnalathavempaty.trail9.dummy.DummyContent;
import com.example.swarnalathavempaty.trail9.dummy.DummyContent.DummyItem;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;


public class FavLegisItemFragment extends Fragment implements View.OnClickListener{

    // TODO: Customize parameter argument names
    private static final String ARG_COLUMN_COUNT = "column-count";
    // TODO: Customize parameters
    private int mColumnCount = 1;
    Map<String, Integer> mapIndex = null;
    ListView FavLegisListView;
    JSONArray FavLegisList=new JSONArray();
    ListView FavlegisListView;
    JSONArray legislist;
    LinearLayout indexLayout;

    Gson gson=new Gson();
    ArrayList<String> fav =new ArrayList<String>();




    /**
     * Mandatory empty constructor for the fragment manager to instantiate the
     * fragment (e.g. upon screen orientation changes).
     */
    public FavLegisItemFragment() {
    }

    @Override
    public void onResume()
    {
        super.onResume();
        try {
            LoadLegisData();
            sidebar();
        } catch (JSONException e) {
            e.printStackTrace();
        }

        updateside();
    }


    // TODO: Customize parameter initialization
    @SuppressWarnings("unused")
    public static FavLegisItemFragment newInstance(int columnCount) {
        FavLegisItemFragment fragment = new FavLegisItemFragment();
        Bundle args = new Bundle();
        args.putInt(ARG_COLUMN_COUNT, columnCount);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (getArguments() != null) {
            mColumnCount = getArguments().getInt(ARG_COLUMN_COUNT);
        }
         }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_favlegisitem_list, container, false);

        FavLegisListView=(ListView) view.findViewById(R.id.favlegislist);
         indexLayout = (LinearLayout) view.findViewById(R.id.side_index);
       try {
            LoadLegisData();
           sidebar();
        } catch (JSONException e) {
            e.printStackTrace();
        }

        updateside();
        return view;
    }


    private void sidebar() throws JSONException {
        mapIndex = new LinkedHashMap<String, Integer>();
        for (int i = 0; i < FavLegisList.length(); i++) {
            JSONObject legis = FavLegisList.getJSONObject(i);
            String index = null;
            try {
                index = (String.valueOf(legis.getString("last_name")).substring(0, 1)).toUpperCase();
            } catch (JSONException e) {
                e.printStackTrace();
            }

            if (mapIndex.get(index) == null)
                mapIndex.put(index, i);

        }

         }

    private void updateside() {
        TextView textView;


        List<String> indexList = new ArrayList<String>(mapIndex.keySet());
        for (String index : indexList) {
            textView = (TextView) getActivity().getLayoutInflater().inflate(
                    R.layout.sidebar, null);
            textView.setText(index.toUpperCase());
            textView.setOnClickListener(this);
            indexLayout.addView(textView);
        }
    }

@Override
    public void onClick(View view) {
        TextView selectedIndex = (TextView) view;
        FavLegisListView.setSelection(mapIndex.get(selectedIndex.getText()));
    }



    private void LoadLegisData() throws JSONException {
        FavLegisList=new JSONArray();
        SharedPreferences pref = getActivity().getSharedPreferences("Legis", Context.MODE_PRIVATE);
        String jsonlegis = pref.getString("legislist", null);


        SharedPreferences pref1 = getActivity().getSharedPreferences("Fav", Context.MODE_PRIVATE);
        String jsonFavlegis = pref1.getString("Legis", null);
////Log.d("Hi1",jsonlegis);
        ////Log.d("Hi1",jsonFavlegis);
        if (jsonlegis != null && jsonFavlegis != null) {

            ////Log.d("Hi1","inside");
            JSONObject json = new JSONObject(jsonlegis);
            legislist=json.getJSONArray("results");
           // legislist = gson.fromJson(jsonlegis, new TypeToken<JSONArray>(){}.getType());

            fav = gson.fromJson(jsonFavlegis, new TypeToken<ArrayList<String>>() {
            }.getType());

//////Log.d("hi1",legislist.getJSONObject(10).getString("bioguide_id"));

            for (int i = 0; i < fav.size(); i++) {
                for(int j=0;j<legislist.length();j++)
                {
                    if(fav.get(i).compareTo(legislist.getJSONObject(j).getString("bioguide_id")) == 0){
                        // ////Log.d("inside","hurray");
                        FavLegisList.put(legislist.getJSONObject(j));
                        break;
                    }
                }
            }
        }
        FavLegisList=sortJsonArray(FavLegisList);
        FavLegisListView.setAdapter(new FavLegisCustomAdapter(getActivity(),R.layout.fragment_favlegisitem,FavLegisList));


    }
    public JSONArray sortJsonArray(JSONArray array) {
        List<JSONObject> jsonarray = new ArrayList<JSONObject>();
        try {
            for (int i = 0; i < array.length(); i++) {

                jsonarray.add(array.getJSONObject(i));
            }

            Collections.sort(jsonarray, new Comparator<JSONObject>() {
                @Override
                public int compare(JSONObject lhs, JSONObject rhs) {
                    String lel="";
                    String rel="";

                    try {
                        lel = lhs.getString("last_name");

                        rel = rhs.getString("last_name");

                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                    return lel.compareTo(rel);
                }
            });
        }catch (JSONException e) {
            e.printStackTrace();
        }

        return new JSONArray(jsonarray);
    }

}
