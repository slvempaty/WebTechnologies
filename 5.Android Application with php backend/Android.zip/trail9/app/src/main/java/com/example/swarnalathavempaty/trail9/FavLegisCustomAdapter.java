package com.example.swarnalathavempaty.trail9;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONException;

/**
 * Created by swarna latha vempaty on 24-Nov-16.
 */

public class FavLegisCustomAdapter extends BaseAdapter {

    JSONArray result;
    Context context;
    int Legisresource;


    public FavLegisCustomAdapter(Context mainActivity,int resource, JSONArray LegisList) {

        result=LegisList;
        context=mainActivity;
        Legisresource=resource;

    }
    @Override
    public int getCount() {

        return result.length();
    }

    @Override
    public Object getItem(int position) {

        return position;
    }

    @Override
    public long getItemId(int position) {

        return position;
    }

    public class LegislatorRowItem
    {
        TextView LegisName;
        ImageView LegisIcon;
        TextView LegisState;
    }
    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        LayoutInflater inflater = (LayoutInflater) context.
                getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        LegislatorRowItem LegislatorRowItemObj = new LegislatorRowItem();
        View rowView;
        rowView = inflater.inflate(Legisresource, parent, false);
        LegislatorRowItemObj.LegisName = (TextView) rowView.findViewById(R.id.flegisname);
        LegislatorRowItemObj.LegisState = (TextView) rowView.findViewById(R.id.flegisstate);
        LegislatorRowItemObj.LegisIcon = (ImageView) rowView.findViewById(R.id.flegisicon);

        try {


            String district = (result.getJSONObject(position).getString("district") == "null") ? "0" : result.getJSONObject(position).getString("district");

            LegislatorRowItemObj.LegisName.setText(result.getJSONObject(position).getString("last_name") + "," + result.getJSONObject(position).getString("first_name"));
            LegislatorRowItemObj.LegisState.setText("(" + result.getJSONObject(position).getString("party") + ") " + result.getJSONObject(position).getString("state_name") + " " + "District " + district);
            Picasso.with(context)
                    .load("https://theunitedstates.io/images/congress/original/" + result.getJSONObject(position).getString("bioguide_id") + ".jpg")
                    .placeholder(android.R.drawable.ic_menu_camera)
                    .error(android.R.drawable.ic_menu_camera)
                    .resize(150,150)
                    .into(LegislatorRowItemObj.LegisIcon);
        }


        catch (JSONException e) {
            e.printStackTrace();
        }
        rowView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent in=new Intent(context,LegisDetailsActivity.class);

                // Toast.makeText(context, "You Clicked "+result[position], Toast.LENGTH_LONG).show();
                try {
                    String fb="N.A";
                    if(result.getJSONObject(position).has("facebook_id")){
                        fb=(result.getJSONObject(position).getString("facebook_id") == "null") ? "N.A" : result.getJSONObject(position).getString("facebook_id");

                    }

                    String tw="N.A";
                    if(result.getJSONObject(position).has("twitter_id")){
                        tw=(result.getJSONObject(position).getString("twitter_id") == "null") ? "N.A" : result.getJSONObject(position).getString("twitter_id");

                    }
                    String wb=(result.getJSONObject(position).getString("website") == "null") ? "N.A" : result.getJSONObject(position).getString("website");
                    String photo="https://theunitedstates.io/images/congress/original/"+result.getJSONObject(position).getString("bioguide_id")+".jpg";
                    String party = result.getJSONObject(position).getString("party");
                    String name = result.getJSONObject(position).getString("title")+"."+result.getJSONObject(position).getString("last_name")+","+result.getJSONObject(position).getString("first_name");
                    String email = (result.getJSONObject(position).getString("oc_email") == "null") ? "N.A" : result.getJSONObject(position).getString("oc_email");
                    String chamber = result.getJSONObject(position).getString("chamber");
                    String phone = result.getJSONObject(position).getString("phone");

                    String start =(result.getJSONObject(position).getString("term_start"));

                   /*     DateFormat df = new SimpleDateFormat("MMM dd, yyyy");
                        Date startDate=new Date();
                        try {
                            startDate = df.parse(start);
                            String newDateString = df.format(startDate);

                        } catch (ParseException e) {
                            e.printStackTrace();
                        }




                        Date endDate =new Date();
                        try {
                            endDate = df.parse(end);
                            String endDateString = df.format(endDate);

                        } catch (ParseException e) {
                            e.printStackTrace();
                        }



                        Calendar startd= Calendar.getInstance();
                        startd.setTime(startDate);
                        Calendar td=Calendar.getInstance();
                        String num=Long.toString (td.getTimeInMillis()-startd.getTimeInMillis());
////Log.d("date",num);*/

                    String end = result.getJSONObject(position).getString("term_end");
                    String office = result.getJSONObject(position).getString("office");
                    String state = result.getJSONObject(position).getString("state_name");
                    String fax = (result.getJSONObject(position).getString("fax") == "null") ? "N.A" : result.getJSONObject(position).getString("fax");
                    String birthday=result.getJSONObject(position).getString("birthday");

                    in.putExtra("bio",result.getJSONObject(position).getString("bioguide_id"));
                    in.putExtra("photo",photo);
                    in.putExtra("party",party);
                    in.putExtra("name",name );
                    in.putExtra("tw",tw);
                    in.putExtra("fb",fb);
                    in.putExtra("wb",wb );
                    in.putExtra("email",email);
                    in.putExtra("chamber",chamber);
                    in.putExtra("phone",phone);
                    in.putExtra("start",start);
                    in.putExtra("end",end);
                    in.putExtra("office",office);
                    in.putExtra("state",state);
                    in.putExtra("fax",fax);
                    in.putExtra("birthday",birthday);

                } catch (JSONException e) {
                    e.printStackTrace();
                }


                context.startActivity(in);

                    /*FragmentTransaction ft = ((FragmentActivity)context).getSupportFragmentManager().beginTransaction();
                    ft.replace(r.id.content_frame, new LegisDetailsPage());
                    ft.addToBackStack(null);
                    ft.commit();*/

                //  FragmentManager fm = ((Activity)context).getFragmentManager();
                //   fm.beginTransaction().replace(r.id.content_main, new LegisDetailsPage()).commit();

            }
        });
        return rowView;
    }

}


