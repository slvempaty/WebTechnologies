package com.example.swarnalathavempaty.trail9;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;

import com.example.swarnalathavempaty.trail9.dummy.DummyContent;
import com.example.swarnalathavempaty.trail9.dummy.DummyContent.DummyItem;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;


public class FavCommItemFragmentFragment extends Fragment {

    // TODO: Customize parameter argument names
    private static final String ARG_COLUMN_COUNT = "column-count";
    // TODO: Customize parameters
    private int mColumnCount = 1;

    ListView FavCommListView;
    ArrayList<HashMap<String, String>> CommFavList=new ArrayList<HashMap<String, String>>();
    ArrayList<HashMap<String, String>> ComList =new ArrayList<HashMap<String, String>>();
    ArrayList<HashMap<String, String>> ComListjoint =new ArrayList<HashMap<String, String>>();
    ArrayList<HashMap<String, String>> ComListsen =new ArrayList<HashMap<String, String>>();


    JSONArray Comm=new JSONArray(),Comm1=new JSONArray();
    JSONArray Comm2=new JSONArray();
    JSONArray Comm3=new JSONArray();

    Gson gson=new Gson();
    ArrayList<String> fav =new ArrayList<String>();



    public FavCommItemFragmentFragment() {
    }

    // TODO: Customize parameter initialization
    @SuppressWarnings("unused")
    public static FavCommItemFragmentFragment newInstance(int columnCount) {
        FavCommItemFragmentFragment fragment = new FavCommItemFragmentFragment();
        Bundle args = new Bundle();
        args.putInt(ARG_COLUMN_COUNT, columnCount);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (getArguments() != null) {
            mColumnCount = getArguments().getInt(ARG_COLUMN_COUNT);
        }
    }

    @Override
    public void onResume()
    {
        super.onResume();
        try {
            LoadCommBillsdata();// Set the adapter
        } catch (JSONException e) {
            e.printStackTrace();
        }
        adapterfunc();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_favcommitemfragment_list, container, false);

        FavCommListView=(ListView) view.findViewById(R.id.favcommlist);

        try {
            LoadCommBillsdata();// Set the adapter
        } catch (JSONException e) {
            e.printStackTrace();
        }
        adapterfunc();

        return view;
    }

    public void adapterfunc()
    {
        ListAdapter adapter = new SimpleAdapter(getActivity(),
                CommFavList,
                R.layout.fragment_favcommitemfragment,
                new String[] { "Comm","name","chamber" },
                new int[] { R.id.fcommid,R.id.fcomname,R.id.fcomchamber });
        FavCommListView.setAdapter(adapter);


        // Set the adapter

        FavCommListView.setOnItemClickListener(new AdapterView.OnItemClickListener()
        {
            @Override
            public void onItemClick(AdapterView<?> parent, View view,
                                    int position, long id) {

                Intent in=new Intent(getActivity(),ComDetails.class);


                Log.d("abc",CommFavList.get(position).get("Comm"));
                String clicked=CommFavList.get(position).get("Comm");

                for (int i = 0; i < Comm1.length(); i++) {
                    JSONObject l = null;
                    try {
                        l = Comm1.getJSONObject(i);
                        Log.d("abc",l.getString("committee_id"));

                        if (clicked.compareTo (l.getString("committee_id"))==0) {
                            Log.d("abc","inside");
                            String name="N.A";
                            if( l.has("name")){
                                name = l.getString("name");}

                            String chamber = "N.A";
                            if( l.has("chamber")){
                                l.getString("chamber");}

                            String parent_committee_id ="N.A";
                            if( l.has("parent_committee_id")){
                                l.getString("parent_committee_id");}

                            String contact="N.A";
                            if( l.has("contact")){

                                contact = l.getString("contact");}

                            String office="N.A";

                            if( l.has("office")){
                                office = l.getString("office");}

                            in.putExtra("name", name);
                            in.putExtra("Comm",clicked);

                            in.putExtra("parent_committee_id", parent_committee_id);
                            in.putExtra("chamber", "House");
                            in.putExtra("contact", contact);
                            in.putExtra("office", office);

                            break;

                        }

                    } catch (JSONException e) {
                        Log.d("abc1","exception");
                        e.printStackTrace();
                    }

                }
                getActivity().startActivity(in);
            }});




    }

    private void LoadCommBillsdata() throws JSONException {
        SharedPreferences pref = getActivity().getSharedPreferences("Comm", Context.MODE_PRIVATE);
        String jsoncomm = pref.getString("commlist", null);
        String jsoncommjoint=pref.getString("commlistjoint",null);
        String jsoncommsen=pref.getString("commlistsenate",null);

        String comm = pref.getString("commfull", null);
        CommFavList=new  ArrayList<HashMap<String, String>>();
        // Comm=new JSONArray();

        SharedPreferences pref1 = getActivity().getSharedPreferences("Fav", Context.MODE_PRIVATE);
        String jsonFavcomm = pref1.getString("Comm", null);

        if (jsoncomm != null && jsonFavcomm != null & comm !=null) {

            ComList = gson.fromJson(jsoncomm, new TypeToken<ArrayList<HashMap<String, String>>>() {
            }.getType());

            JSONObject json = new JSONObject(comm);
             Comm1=json.getJSONArray("results");

            fav = gson.fromJson(jsonFavcomm, new TypeToken<ArrayList<String>>() {
            }.getType());
//Log.d("success1",jsonFavcomm);

            for (int i = 0; i < fav.size(); i++) {
                for(int j=0;j<ComList.size();j++)
                {
                    if(fav.get(i).compareTo(ComList.get(j).get("Comm")) == 0){
                        // ////Log.d("inside","hurray");
                        CommFavList.add(ComList.get(j));
                       // Comm.put(Comm1.get(j));
                    }
                }
            }
        }

        //new code
//Log.d("success1","outside1");
        if (jsoncommjoint != null && jsonFavcomm != null & comm !=null) {
            //Log.d("success1","outside2");


            ComListjoint = gson.fromJson(jsoncommjoint, new TypeToken<ArrayList<HashMap<String, String>>>() {
            }.getType());

          //  JSONObject json = new JSONObject(comm);
           // Comm2=json.getJSONArray("results");

            fav = gson.fromJson(jsonFavcomm, new TypeToken<ArrayList<String>>() {
            }.getType());

            //Log.d("success1",jsonFavcomm);
            for (int i = 0; i < fav.size(); i++) {
                for(int j=0;j<ComListjoint.size();j++)
                {
                    //Log.d("success1","heyin");
                    if(fav.get(i).compareTo(ComListjoint.get(j).get("Comm")) == 0){
                        // ////Log.d("inside","hurray");
                        CommFavList.add(ComListjoint.get(j));
                      //  Comm.put(Comm2.get(j));
                    }
                }
            }
            //Log.d("success1","hey");
        }
        //Log.d("success1","outside1");

//Log.d("success1",jsoncommsen);
        if (jsoncommsen != null && jsonFavcomm != null & comm !=null) {
            //Log.d("success1","outside1");

            //Log.d("inside","senate");
            ComListsen = gson.fromJson(jsoncommsen, new TypeToken<ArrayList<HashMap<String, String>>>() {
            }.getType());

           // JSONObject json = new JSONObject(comm);
           // Comm3=json.getJSONArray("results");

            fav = gson.fromJson(jsonFavcomm, new TypeToken<ArrayList<String>>() {
            }.getType());


            for (int i = 0; i < fav.size(); i++) {
                for(int j=0;j<ComListsen.size();j++)
                {
                    if(fav.get(i).compareTo(ComListsen.get(j).get("Comm")) == 0){
                        // ////Log.d("inside","hurray");
                        CommFavList.add(ComListsen.get(j));
                     //   Comm.put(Comm3.get(j));
                    }
                }
            }
        }
        //new code done


       // CommFavList=sortJsonArray(CommFavList);
            }

    public ArrayList<HashMap<String,String>> sortJsonArray(ArrayList<HashMap<String,String>> array) {
        List<JSONObject> jsonarray = new ArrayList<JSONObject>();


        Collections.sort(array, new Comparator<HashMap<String,String>>() {
            @Override
            public int compare(HashMap<String,String> lhs, HashMap<String,String> rhs) {
                String lel="";
                String rel="";


                lel = lhs.get("name");

                rel = rhs.get("name");





                return lel.compareTo(rel);
            }
        });

        return new ArrayList<HashMap<String,String>>(array);
    }

}
