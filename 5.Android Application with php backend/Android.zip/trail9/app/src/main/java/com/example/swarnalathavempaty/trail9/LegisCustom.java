package com.example.swarnalathavempaty.trail9;

import android.app.Activity;
import android.app.FragmentManager;
import android.content.Intent;
import android.icu.text.DateFormat;
import android.icu.text.SimpleDateFormat;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentTransaction;
import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import com.squareup.picasso.Picasso;

import java.text.ParseException;
import java.util.Calendar;
import java.util.Date;


/**
 * Created by swarna latha vempaty on 20-Nov-16.
 */

public class LegisCustom extends BaseAdapter {

        JSONArray result;
        Context context;
        int Legisresource;


        public LegisCustom(Context mainActivity,int resource, JSONArray LegisList) {

            result=LegisList;
            context=mainActivity;
            Legisresource=resource;

        }
        @Override
        public int getCount() {

            return result.length();
        }

        @Override
        public Object getItem(int position) {

            return position;
        }

        @Override
        public long getItemId(int position) {

            return position;
        }

        public class LegislatorRowItem
        {
            TextView LegisName;
            ImageView LegisIcon;
            TextView LegisState;
        }
        @Override
        public View getView(final int position, View convertView, ViewGroup parent) {
            LayoutInflater inflater = (LayoutInflater) context.
                    getSystemService(Context.LAYOUT_INFLATER_SERVICE);

            LegislatorRowItem LegislatorRowItemObj = new LegislatorRowItem();
            View rowView;
            rowView = inflater.inflate(Legisresource, parent, false);
            LegislatorRowItemObj.LegisName = (TextView) rowView.findViewById(R.id.legisname);
            LegislatorRowItemObj.LegisState = (TextView) rowView.findViewById(R.id.legisstate);
            LegislatorRowItemObj.LegisIcon = (ImageView) rowView.findViewById(R.id.legisicon);

            try {


                String district = (result.getJSONObject(position).getString("district") == "null") ? "0" : result.getJSONObject(position).getString("district");

                LegislatorRowItemObj.LegisName.setText(result.getJSONObject(position).getString("last_name") + "," + result.getJSONObject(position).getString("first_name"));
                LegislatorRowItemObj.LegisState.setText("(" + result.getJSONObject(position).getString("party") + ") " + result.getJSONObject(position).getString("state_name") + " " + "District " + district);
                Picasso.with(context)
                        .load("https://theunitedstates.io/images/congress/original/" + result.getJSONObject(position).getString("bioguide_id") + ".jpg")
                        .placeholder(android.R.drawable.ic_menu_camera)
                        .error(android.R.drawable.ic_menu_camera)
                        .resize(150,150)
                        .into(LegislatorRowItemObj.LegisIcon);
}


          catch (JSONException e) {
                e.printStackTrace();
            }
            rowView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    Intent in=new Intent(context,LegisDetailsActivity.class);

                    // Toast.makeText(context, "You Clicked "+result[position], Toast.LENGTH_LONG).show();
                    try {
                        String fb="N.A";
                        if(result.getJSONObject(position).has("facebook_id")){
                            fb=(result.getJSONObject(position).getString("facebook_id") == "null") ? "N.A" : result.getJSONObject(position).getString("facebook_id");

                        }

                        String tw="N.A";
                        if(result.getJSONObject(position).has("twitter_id")){
                            tw=(result.getJSONObject(position).getString("twitter_id") == "null") ? "N.A" : result.getJSONObject(position).getString("twitter_id");

                        }
                        String wb=(result.getJSONObject(position).getString("website") == "null") ? "N.A" : result.getJSONObject(position).getString("website");
 String photo="https://theunitedstates.io/images/congress/original/"+result.getJSONObject(position).getString("bioguide_id")+".jpg";
                        String party = result.getJSONObject(position).getString("party");
                        String name = result.getJSONObject(position).getString("title")+"."+result.getJSONObject(position).getString("last_name")+","+result.getJSONObject(position).getString("first_name");
                        String email = (result.getJSONObject(position).getString("oc_email") == "null") ? "N.A" : result.getJSONObject(position).getString("oc_email");
                        String chamber = result.getJSONObject(position).getString("chamber");
                        String phone = result.getJSONObject(position).getString("phone");

                        String start =(result.getJSONObject(position).getString("term_start"));
                        String end = result.getJSONObject(position).getString("term_end");

                        java.text.SimpleDateFormat dateFormat = new java.text.SimpleDateFormat("yyyy-MM-dd");
                        Date convertedDate1 = new Date();
                        Date convertedDate2 = new Date();
                        Date today=new Date();

                        try {
                            convertedDate1 = dateFormat.parse(start);
                            convertedDate2 = dateFormat.parse(end);
                            //  //Log.d("date1",convertedDate1.toString());
                            // //Log.d("date2",convertedDate2.toString());

                        } catch (ParseException e) {
                            // TODO Auto-generated catch block
                            e.printStackTrace();
                        }
                        long numa=today.getTime()-convertedDate1.getTime();
                        long deno=convertedDate2.getTime()-convertedDate1.getTime();

                        int frac=(int)((numa*100)/deno);

                       // //Log.d("frac1",diff.toString());
                     //   //Log.d("frac1",frac);
                  String office = result.getJSONObject(position).getString("office");
                        String state = result.getJSONObject(position).getString("state_name");
                        String fax = (result.getJSONObject(position).getString("fax") == "null") ? "N.A" : result.getJSONObject(position).getString("fax");
String birthday=result.getJSONObject(position).getString("birthday");
in.putExtra("pb",frac);
                        in.putExtra("bio",result.getJSONObject(position).getString("bioguide_id"));
                        in.putExtra("photo",photo);
                        in.putExtra("party",party);
                        in.putExtra("name",name );
                        in.putExtra("tw",tw);
                        in.putExtra("fb",fb);
                        in.putExtra("wb",wb );
                        in.putExtra("email",email);
                        in.putExtra("chamber",chamber);
                        in.putExtra("phone",phone);
                        in.putExtra("start",start);
                        in.putExtra("end",end);
                        in.putExtra("office",office);
                        in.putExtra("state",state);
                        in.putExtra("fax",fax);
                        in.putExtra("birthday",birthday);

                    } catch (JSONException e) {
                        e.printStackTrace();
                    }


                    context.startActivity(in);

                    /*FragmentTransaction ft = ((FragmentActivity)context).getSupportFragmentManager().beginTransaction();
                    ft.replace(r.id.content_frame, new LegisDetailsPage());
                    ft.addToBackStack(null);
                    ft.commit();*/

                   //  FragmentManager fm = ((Activity)context).getFragmentManager();
                     //   fm.beginTransaction().replace(r.id.content_main, new LegisDetailsPage()).commit();

                }
            });
            return rowView;
        }

    }

