
References:

https://guides.codepath.com/android/Fragment-Navigation-Drawer
https://www.simplifiedcoding.net/android-navigation-drawer-example-using-fragments/
http://stackoverflow.com/questions/35058819/android-tablayout-inside-fragment
http://stackoverflow.com/questions/9529267/how-to-add-tabhost-in-fragments
http://www.androidhive.info/2012/05/android-combining-tab-layout-and-list-view/
http://www.vogella.com/tutorials/AndroidListView/article.html#listfragments
http://stackoverflow.com/questions/31828574/java-android-how-to-sort-a-jsonarray-based-on-keys
http://androidopentutorials.com/android-listview-with-alphabetical-side-index/
http://colintmiller.com/how-to-add-text-over-a-progress-bar-on-android/