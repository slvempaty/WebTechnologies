<?php

if(isset($_GET['legislator']) ) {
    $keyword = $_GET['legislator'];
  if(strtoupper($keyword)=='ALL') $RestURL="http://104.198.0.197:8080/legislators?per_page=all&apikey=d49fbc4e14b84390987ebed9dd3dec05";
       
   header('Content-Type: application/json');
    echo file_get_contents($RestURL);

    }
else if(isset($_GET['Committees'])){
    $keyword = $_GET['Committees'];
  $RestURL="http://104.198.0.197:8080/committees?member_ids=$keyword&apikey=d49fbc4e14b84390987ebed9dd3dec05&per_page=5";
       
   header('Content-Type: application/json');
    echo file_get_contents($RestURL);
}

  else if(isset($_GET['Bills'])){
    $keyword = $_GET['Bills'];
  $RestURL="http://104.198.0.197:8080/bills?sponsor_id=$keyword&apikey=d49fbc4e14b84390987ebed9dd3dec05&per_page=5";
       
   header('Content-Type: application/json');
    echo file_get_contents($RestURL);
}
else if(isset($_GET['BillDataActive'])){
    $keyword = $_GET['BillDataActive'];
    if(strtoupper($keyword)=='ALL')
  $RestURL="http://104.198.0.197:8080/bills?apikey=d49fbc4e14b84390987ebed9dd3dec05&per_page=50&history.active=true";
       
   header('Content-Type: application/json');
    echo file_get_contents($RestURL);
}
else if(isset($_GET['BillDataNew'])){
    $keyword = $_GET['BillDataNew'];
    if(strtoupper($keyword)=='ALL')
  $RestURL="http://104.198.0.197:8080/bills?apikey=d49fbc4e14b84390987ebed9dd3dec05&per_page=50&history.active=false";
       
   header('Content-Type: application/json');
    echo file_get_contents($RestURL);
}
else if(isset($_GET['ComData'])){
    $keyword = $_GET['ComData'];
    if(strtoupper($keyword)=='ALL')
  $RestURL="http://104.198.0.197:8080/committees?per_page=all&apikey=d49fbc4e14b84390987ebed9dd3dec05";
       
   header('Content-Type: application/json');
    echo file_get_contents($RestURL);
}

?>
