<!Doctype html>
<html>

<head>
    <!-- Latest compiled and minified CSS -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

    <!-- jQuery library -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>

    <!-- Latest compiled JavaScript -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.4.8/angular.min.js"></script>
    <script src="dirPagination.js"></script>
    <script src="moment.js"></script>

    <script type="text/javascript">
        var flag = 0; //navbar is shown
        $(document).ready(function() {
            $("#toggleButton").click(function() {
                $("#exCollapsingNavbar").toggle();
                if (!flag) {
                    $(".MainContentArea").css({
                        "padding-left": "0px"
                    });
                    flag = 1; //nav bar hidden
                } else {

                    var width = $(window).width();
                    if (width <= 680) {
                        $(".MainContentArea").css({
                            "padding-left": "35px"
                        });
                    } else {
                        $(".MainContentArea").css({
                            "padding-left": "170px"
                        });
                    }
                    flag = 0;
                }

            });
        });


        var app = angular.module('congress', ['angularUtils.directives.dirPagination']);
        app.controller('legislatorsContrl', function($scope, $http, $attrs) {




            $http.get('trail82.php', {
                params: {
                    "legislator": "all"
                }
            }).then(function successCallback(response) {


                $scope.myData = response.data.results;


            }, function errorCallback(response) {
                alert("error in retreiving data from API");

            });

            $http.get('trail82.php', {
                params: {
                    "BillDataActive": "all"
                }
            }).then(function successCallback(response) {


                $scope.myActiveBillsData = response.data.results;



            }, function errorCallback(response) {
                alert("error in retreiving data from API");

            });
            $http.get('trail82.php', {
                params: {
                    "BillDataNew": "all"
                }
            }).then(function successCallback(response) {


                $scope.myNewBillsData = response.data.results;



            }, function errorCallback(response) {
                alert("error in retreiving data from API");

            });


            $http.get('trail82.php', {
                params: {
                    "ComData": "all"
                }
            }).then(function successCallback(response) {


                $scope.myComData = response.data.results;



            }, function errorCallback(response) {
                alert("error in retreiving data from API");

            });


            /*

                        $http.get('leg.json')
                            .then(function(res) {
                                $scope.myData = res.data.results;
                            });

                        $http.get('bills.json')
                            .then(function(res) {
                                $scope.myActiveBillsData = res.data.results;


                            });

                        $http.get('bills2.json')
                            .then(function(res) {
                                $scope.myNewBillsData = res.data.results;


                            });


                        $http.get('comm.json')
                            .then(function(res) {
                                $scope.myComData = res.data.results;
                            });

            */
            $scope.UpdateFavTab = function() {
                $scope.myFavLegisData = [];
                var TempLegis = JSON.parse(localStorage.getItem('FavLegisArray')) || [];
                angular.forEach(TempLegis, function(result1, index) {
                    angular.forEach($scope.myData, function(result2, index) {
                        if (result1 == result2.bioguide_id) {
                            $scope.myFavLegisData.push(result2);
                        }

                    });
                });

                $scope.myFavBillData = [];
                var TempBills = JSON.parse(localStorage.getItem('FavBillArray')) || [];
                var myBillsData = ($scope.myActiveBillsData).concat($scope.myNewBillsData);
                angular.forEach(TempBills, function(result1, index) {
                    angular.forEach(myBillsData, function(result2, index) {
                        if (result1 == result2.bill_id) {
                            $scope.myFavBillData.push(result2);
                        }

                    });
                });
                $scope.myFavCommData = [];
                var TempComm = JSON.parse(localStorage.getItem('FavComArray')) || [];
                angular.forEach(TempComm, function(result1, index) {
                    angular.forEach($scope.myComData, function(result2, index) {
                        if (result1 == result2.committee_id) {
                            $scope.myFavCommData.push(result2);
                        }

                    });
                });
            };

            $scope.Billdetails = function(billid, VDId) {
                var myBillsData = ($scope.myActiveBillsData).concat($scope.myNewBillsData);
                angular.forEach(myBillsData, function(result, index) {
                    if (result.bill_id == billid) {
                        $scope.BillID = result.bill_id;
                        $scope.IsFavBill(billid, VDId);
                        $scope.BillTitle = result.official_title;
                        $scope.BillType = result.bill_type;
                        $scope.BillSponsor = result.sponsor;
                        $scope.BillChamber = result.chamber;
                        if (result.history.active)
                            $scope.BillStatus = "Active";
                        else
                            $scope.BillStatus = "New";
                        var intro = result.introduced_on;
                        $scope.BillIntro = moment(intro).format('MMM D,YYYY');

                        $scope.BillCongressUrl = result.urls.congress;
                        $scope.Billversion = result.last_version.version_name;
                        $scope.BillPDF = result.last_version.urls.pdf;



                    }
                });
            };



            $scope.FavLegis = function(LegisBio, elemID) {



                var FavLegisArray = JSON.parse(localStorage.getItem("FavLegisArray"));
                if (FavLegisArray === null) { //while inserting into local storage for the first time
                    FavLegisArray = [];
                    FavLegisArray.push(LegisBio);
                    if (elemID != null) {
                        document.getElementById(elemID).style.color = "yellow";
                    }

                } else {

                    var indexofLegisBio = FavLegisArray.indexOf(LegisBio)
                    if (indexofLegisBio > -1) {

                        FavLegisArray.splice(indexofLegisBio, 1);
                        if (elemID != null) {
                            document.getElementById(elemID).style.color = "white";
                        }
                    } else {

                        FavLegisArray.push(LegisBio);
                        if (elemID != null) {
                            document.getElementById(elemID).style.color = "yellow";
                        }
                    }
                }
                localStorage.setItem("FavLegisArray", JSON.stringify(FavLegisArray));
                $scope.UpdateFavTab();
            };
            $scope.FavBills = function(BillID, elemID) {



                var FavBillArray = JSON.parse(localStorage.getItem("FavBillArray"));
                if (FavBillArray === null) { //while inserting into local storage for the first time
                    FavBillArray = [];
                    FavBillArray.push(BillID);
                    document.getElementById(elemID).style.color = "yellow";

                } else {

                    var indexofBillID = FavBillArray.indexOf(BillID)
                    if (indexofBillID > -1) {

                        FavBillArray.splice(indexofBillID, 1);
                        document.getElementById(elemID).style.color = "white";
                    } else {

                        FavBillArray.push(BillID);
                        document.getElementById(elemID).style.color = "yellow";
                    }
                }
                localStorage.setItem("FavBillArray", JSON.stringify(FavBillArray));
                $scope.UpdateFavTab();
            };
            $scope.FavComm = function(CommID) {



                var FavComArray = JSON.parse(localStorage.getItem("FavComArray"));
                if (FavComArray === null) { //while inserting into local storage for the first time
                    FavComArray = [];
                    FavComArray.push(CommID);
                    document.getElementById(CommID).style.color = "yellow";

                } else {

                    var indexofCommID = FavComArray.indexOf(CommID)
                    if (indexofCommID > -1) {

                        FavComArray.splice(indexofCommID, 1);
                        document.getElementById(CommID).style.color = "white";
                    } else {

                        FavComArray.push(CommID);
                        document.getElementById(CommID).style.color = "yellow";
                    }
                }
                localStorage.setItem("FavComArray", JSON.stringify(FavComArray));
                $scope.UpdateFavTab();
            };

            $scope.IsFavBill = function(BillID, VDelemID) {
                var FavBillsArray = JSON.parse(localStorage.getItem("FavBillArray"));
                if (FavBillsArray === null) { //opening for the first time

                    document.getElementById(VDelemID).style.color = "white";

                } else {

                    var indexofBill = FavBillsArray.indexOf(BillID)
                    if (indexofBill > -1) {


                        document.getElementById(VDelemID).style.color = "yellow";
                    } else {


                        document.getElementById(VDelemID).style.color = "white";
                    }
                }



            };

            $scope.IsFavLegis = function(LegisBio, VDelemID) {
                var FavLegisArray = JSON.parse(localStorage.getItem("FavLegisArray"));
                if (FavLegisArray === null) { //opening for the first time

                    document.getElementById(VDelemID).style.color = "white";

                } else {

                    var indexofLegisBio = FavLegisArray.indexOf(LegisBio)
                    if (indexofLegisBio > -1) {


                        document.getElementById(VDelemID).style.color = "yellow";
                    } else {


                        document.getElementById(VDelemID).style.color = "white";
                    }
                }



            };


            $scope.DelFavBill = function(event) {
                var FavBillArray = JSON.parse(localStorage.getItem("FavBillArray"));

                $scope.FavBills(FavBillArray[event], 'BillsFavStar');

            }

            $scope.DelFavLegis = function(event) {
                var FavLegisArray = JSON.parse(localStorage.getItem("FavLegisArray"));

                $scope.FavLegis(FavLegisArray[event], 'LegisDetailsStar');

            }

            $scope.GetLegisdetails = function(biovalue, VDId) {

                angular.forEach($scope.myData, function(result, index) {
                    if (result.bioguide_id == biovalue) {
                        $scope.LegisBio = biovalue;
                        $scope.LegisName = result.title + "." + result.last_name + "," + result.first_name;

                        if (result.oc_email == null) {
                            $scope.LegisEmail = "NA";
                        } else {
                            $scope.LegisEmail = result.oc_email;
                        }

                        $scope.LegisChamber = result.chamber;
                        $scope.LegisContact = result.phone;
                        $scope.LegisParty = result.party;
                        var startdate = result.term_start;
                        $scope.LegisStartTerm = moment(startdate).format('MMM D,YYYY');
                        var enddate = result.term_end;
                        $scope.LegisEndTerm = moment(enddate).format('MMM D,YYYY');
                        var now = moment(new Date()); //todays date
                        var start = moment(startdate);
                        var end = moment(enddate);
                        var duration = moment.duration(now.diff(start));
                        var deno = moment.duration(end.diff(start));
                        var days = duration.asDays();
                        var denodays = deno.asDays();
                        $scope.Legisterm = (days / denodays) * 100;
                        $scope.LegisOffice = result.office;
                        $scope.LegisState = result.state_name;
                        if (result.hasOwnProperty('fax')) {
                            if (result.fax == null) {
                                $scope.LegisFax = "NA";
                            } else {
                                $scope.LegisFax = result.fax;
                            }

                        } else {
                            $scope.LegisFax = "NA";
                        }
                        var birthtdate = result.birthday;

                        $scope.LegisBirthday = moment(birthtdate).format('MMM D,YYYY');;
                        if (result.hasOwnProperty('twitter_id')) {
                            if (result.twitter_id == null) {
                                $scope.Legistwitter = "NA";
                            } else {
                                $scope.Legistwitter = "https://twitter.com/" + result.twitter_id;

                            }

                        } else {
                            $scope.Legistwitter = "NA";
                        }
                        if (result.hasOwnProperty('facebook_id')) {
                            if (result.facebook_id == null) {
                                $scope.Legisfb = "NA";
                            } else {
                                $scope.Legisfb = "https://facebook.com/" + result.facebook_id;

                            }

                        } else {
                            $scope.Legisfb = "NA";
                        }

                        if (result.website == null) {
                            $scope.Legisweb = "NA";
                        } else {
                            $scope.Legisweb = result.website;
                        }

                        $scope.IsFavLegis(biovalue, VDId);
                        //Committees
                        $http.get('trail82.php', {
                            params: {
                                "Committees": biovalue
                            }
                        }).then(function successCallback(response) {


                            $scope.Committees = response.data.results;


                        }, function errorCallback(response) {


                        });


                        //bills

                        $http.get('trail82.php', {
                            params: {
                                "Bills": biovalue
                            }
                        }).then(function successCallback(response) {


                            $scope.Billsresponse = response.data.results;


                        }, function errorCallback(response) {


                        });



                    }
                });
            };




        });

    </script>

    <style>
        h5 {
            display: inline;
        }
        
        select,
        input {
            float: right;
        }
        
        object {
            width: 100%;
            height: 100%;
        }
        
        .page-header {
            padding-bottom: 40px;
            margin: 20px 0 20px;
        }
        
        .modal-body {
            padding-top: 0px;
        }
        
        body {
            font-family: Calibri;
            background: #F5F5F5;
        }
        
        .glyphicon-star {
            color: white;
            text-shadow: 0 0 1px black, 0 0 1px black, 0 0 1px black, 0 0 1px black;
        }
        
        .DetailsLabel {
            float: left;
        }
        
        .NavbarDiv {
            margin-left: -70px;
            left: 70px;
            width: 170px;
            background: #222;
            position: fixed;
            height: 100%;
            float: none;
        }
        
        @media screen and (max-width:680px) {
            .toHide {
                display: none;
            }
            .NavbarDiv {
                width: 50px;
                padding-left: 2px;
            }
            .Navbar {
                padding-left: 2px;
                font-size: 15px
            }
        }
        
        .Navbar {
            padding-left: 25px;
            font-size: 15px
        }
        
        .Navbar li {
            padding-top: 20px;
            margin-left: 1px;
            list-style-type: none;
            color: #ccc;
        }
        
        .topNameBar {
            text-align: center;
            font-weight: bolder;
        }
        
        .glyphicon {
            padding-right: 7px;
        }
        
        .topGlyph {
            padding: 10px;
        }
        
        .MainContentArea {
            padding-left: 170px;
            width: 100%;
            padding-top: 70px;
        }
        
        .well {
            padding: 10px;
        }
        
        .MainDisplayArea {
            box-shadow: 1px 2px 2px 2px rgba(0, 0, 0, 0.2);
            background: white;
            border-radius: 5px;
            margin: 10px;
        }
        
        #heading,
        #toggleButton {
            float: left;
        }
        
        .Navbar li a {
            color: ghostwhite;
        }
        
        .MainContentArea li a {
            color: #ddd;
        }
        
        .well {
            box-sizing: border-box;
            max-width: 100%;
        }
        
        .paginationControls {
            align-self: center;
        }
        
        hr {
            border-top: 1px solid #ccc;
        }
        
        .btn-custom {
            background-color: #FFFFFF;
            border-color: #CCCCCC;
            color: #333333;
        }
        
        .Detailsbtn {
            float: left;
        }
        
        #exCollapsingNavbar {
            padding-top: 70px;
        }
        
        .tab-content {
            margin: 15px;
        }
        
        .glyphicon-trash:hover {
            color: red;
        }
        
        .nav>li>a:focus,
        .nav>li>a:hover {
            background-color: transparent;
            color: white;
        }
        
        @media screen and (max-width:680px) {
            .toHide {
                display: none;
            }
            .NavbarDiv {
                width: 50px;
                padding-left: 2px;
            }
            .Navbar {
                padding-left: 2px;
                font-size: 15px
            }
            .MainContentArea {
                padding-left: 35px;
            }
            .tab-content {
                margin-right: 0px;
            }
            .container-fluid {
                padding-right: 5px;
            }
            .toChange {
                display: block;
            }
            .toCenter {
                text-align: center;
            }
            .well-lg {
                padding: 20px;
                padding-top: 5px;
            }
        }

    </style>
</head>

<body>
    <div class="page-content">
        <div class="container-fluid">
            <div ng-app="congress" ng-controller="legislatorsContrl">
                <nav class="navbar navbar-default navbar-fixed-top" style="background:white">
                    <div class="topNameBar">
                        <span id="toggleButton"> <span class="glyphicon glyphicon-menu-hamburger topGlyph" aria-hidden="true"></span> </span>
                        <h4>
                            <a href=" http://sunlightfoundation.com/" target="_blank" id="Heading"><img src="logo.png"></a> Congress API</h4>
                    </div>

                </nav>
                <div class="NavbarDiv" id="exCollapsingNavbar">
                    <ul class="Navbar nav">
                        <li class="active"><a data-toggle="tab" href="#LegislatorsTab"><span class="glyphicon glyphicon-user" aria-hidden="true"></span><span class="toHide">Legislators</span></a></li>
                        <li>
                            <a data-toggle="tab" href="#BillsTab"> <span class="glyphicon glyphicon-file" aria-hidden="true"></span><span class="toHide">Bills</span></a>
                        </li>
                        <li>
                            <a data-toggle="tab" href="#CommitteesTab"> <span class="glyphicon glyphicon-log-in" aria-hidden="true"></span><span class="toHide">Committees</span></a>
                        </li>
                        <li>
                            <a data-toggle="tab" href="#FavsTab" ng-click="UpdateFavTab()"> <span class="glyphicon glyphicon-star" aria-hidden="true"></span><span class="toHide">Favorites</span></a>
                        </li>
                    </ul>
                </div>


                <div class="MainContentArea">
                    <div class="tab-content">
                        <div class="tab-pane fade in active" id="LegislatorsTab">
                            <h3 id="ContentHeading">Legislators</h3>
                            <hr/>
                            <div class="MainDisplayArea">
                                <div id="myCarousel" class="carousel slide" data-ride="carousel" data-interval="false">
                                    <div class="carousel-inner" role="listbox">
                                        <div class="Listing item active">

                                            <ul class="nav nav-tabs">
                                                <li class="active"><a data-toggle="tab" href="#state">By State</a></li>
                                                <li><a data-toggle="tab" href="#house">House</a></li>
                                                <li><a data-toggle="tab" href="#senate">Senate</a></li>

                                            </ul>


                                            <div class="tab-content">
                                                <div id="state" class="tab-pane fade in active">
                                                    <div class="well well-lg">

                                                        <h5><b>Legislators By State</b></h5>

                                                        <select name=" state" class="StateDropdown" ng-model="LegissearchText">
                                <option value="">All States</option>
                                <option value="Alabama">Alabama</option>
                                <option value="Alaska">Alaska</option>
                                <option value="Arizona">Arizona</option>
                                <option value="Arkansas">Arkansas</option>
                                <option value="California">California</option>
                                <option value="Colorado">Colorado</option>
                                <option value="Connecticut">Connecticut</option>
                                <option value="Delaware">Delaware</option>
                                <option value="District of Columbia">District of Columbia</option>
                                <option value="Florida">Florida</option>
                                <option value="Georgia">Georgia</option>
                                <option value="Hawaii">Hawaii</option>
                                <option value="Idaho">Idaho</option>
                                <option value="Illinois">Illinois</option>
                                <option value="Indiana">Indiana</option>
                                <option value="Iowa">Iowa</option>
                                <option value="Kansas">Kansas</option>
                                <option value="Kentucky">Kentucky</option>
                                <option value="Louisiana">Louisiana</option>
                                <option value="Maine">Maine</option>
                                <option value="Maryland">Maryland</option>
                                <option value="Massachusetts">Massachusetts</option>
                                <option value="Michigan">Michigan</option>
                                <option value="Minnesota">Minnesota</option>
                                <option value="Mississippi">Mississippi</option>
                                <option value="Missouri">Missouri</option>
                                <option value="Montana">Montana</option>
                                <option value="Nebraska">Nebraska</option>
                                <option value="Nevada">Nevada</option>
                                <option value="New Hampshire">New Hampshire</option>
                                <option value="New Jersey">New Jersey</option>
                                <option value="New Mexico">New Mexico</option>
                                <option value="New York">New York</option>
                                <option value="North Carolina">North Carolina</option>
                                <option value="North Dakota">North Dakota</option>
                                <option value="Ohio">Ohio</option>
                                <option value="Oklahoma">Oklahoma</option>
                                <option value="Oregon">Oregon</option>
                                <option value="Pennsylvania">Pennsylvania</option>
                                <option value="Rhode Island">Rhode Island</option>
                                <option value="South Carolina">South Carolina</option>
                                <option value="South Dakota">South Dakota</option>
                                <option value="Tennessee">Tennessee</option>
                                <option value="Texas">Texas</option>
                                <option value="Utah">Utah</option>
                                <option value="Vermont">Vermont</option>
                                <option value="Virginia">Virginia</option>
                                <option value="Washington">Washington</option>
                                <option value="West Virginia">West Virginia</option>
                                <option value="Wisconsin">Wisconsin</option>
                                <option value="Wyoming">Wyoming</option>
                                </select>

                                                    </div>
                                                    <div class="table-responsive">


                                                        <table class="table">
                                                            <thead>
                                                                <tr>
                                                                    <th>Party</th>
                                                                    <th>Name</th>
                                                                    <th>Chamber</th>
                                                                    <th>District</th>
                                                                    <th>State</th>
                                                                    <th style="width:150px;"></th>
                                                                </tr>
                                                            </thead>
                                                            <tbody id="LegislatorsBody">

                                                                <tr dir-paginate="x in myData|filter:LegissearchText|orderBy:['state_name','last_name']|itemsPerPage:10" pagination-id="LegisAll">

                                                                    <td ng-switch on="x.party">
                                                                        <img src="R.png" ng-switch-when="R" width="25px" height="25px" />
                                                                        <img src="D.png" ng-switch-when="D" width="25px" height="25px" />
                                                                        <p ng-switch-when="I">I</p>
                                                                    </td>

                                                                    <td>{{x.last_name}},{{x.first_name}}</td>
                                                                    <td ng-switch on="x.chamber">
                                                                        <p ng-switch-when="house"><img src="h.png" width="25px" height="25px" /> House</p>
                                                                        <p ng-switch-when="senate"> <img src="s.svg" width="25px" height="25px" /> Senate</p>

                                                                    </td>
                                                                    <td ng-switch on="x.district">
                                                                        <p ng-switch-when="null">NA</p>
                                                                        <p ng-switch-default>District {{x.district}}</p>

                                                                    </td>
                                                                    <td>{{x.state_name}}</td>
                                                                    <td><a role="button" class="btn btn-primary" href="#myCarousel" data-slide="next" ng-click="GetLegisdetails(x.bioguide_id,'LegisDetailsStar')">View Details</a></td>


                                                                </tr>


                                                            </tbody>
                                                        </table>
                                                        <div class="text-center">
                                                            <dir-pagination-controls pagination-id="LegisAll" max-size="10" direction-links="true" boundary-links="true">
                                                            </dir-pagination-controls>
                                                        </div>

                                                    </div>
                                                </div>
                                                <div id="house" class="tab-pane fade">
                                                    <div class="well well-lg">

                                                        <h5><b>Legislators By House</b></h5>
                                                        <input type="text" placeholder="Search" ng-model="HouseSearch" />
                                                    </div>
                                                    <div class="table-responsive">


                                                        <table class="table">
                                                            <thead>
                                                                <tr>
                                                                    <th>Party</th>
                                                                    <th>Name</th>
                                                                    <th>Chamber</th>
                                                                    <th>District</th>
                                                                    <th>State</th>
                                                                    <th style="width:150px;"></th>
                                                                </tr>
                                                            </thead>
                                                            <tbody id="LegislatorsBody">

                                                                <tr dir-paginate="x in myData|filter:'House'|filter:HouseSearch|orderBy:'last_name'|itemsPerPage:10" pagination-id="LegisHouse">

                                                                    <td ng-switch on="x.party">
                                                                        <img src="R.png" ng-switch-when="R" width="25px" height="25px" />
                                                                        <img src="D.png" ng-switch-when="D" width="25px" height="25px" />
                                                                        <p ng-switch-when="I">I</p>
                                                                    </td>

                                                                    <td>{{x.last_name}},{{x.first_name}}</td>
                                                                    <td ng-switch on="x.chamber">
                                                                        <p ng-switch-when="house"><img src="h.png" width="25px" height="25px" /> House</p>
                                                                        <p ng-switch-when="senate"> <img src="s.svg" width="25px" height="25px" /> Senate</p>

                                                                    </td>
                                                                    <td ng-switch on="x.district">
                                                                        <p ng-switch-when="null">NA</p>
                                                                        <p ng-switch-default>District {{x.district}}</p>

                                                                    </td>
                                                                    <td>{{x.state_name}}</td>
                                                                    <td><a role="button" class="btn btn-primary" href="#myCarousel" data-slide="next" ng-click="GetLegisdetails(x.bioguide_id,'LegisDetailsStar')">View Details</a></td>

                                                                </tr>


                                                            </tbody>
                                                        </table>
                                                        <div class="text-center">
                                                            <dir-pagination-controls pagination-id="LegisHouse" max-size="10" direction-links="true" boundary-links="true">
                                                            </dir-pagination-controls>
                                                        </div>

                                                    </div>
                                                </div>
                                                <div id="senate" class="tab-pane fade">
                                                    <div class="well well-lg">

                                                        <h5><b>Legislators By Senate</b></h5>

                                                        <input type="text" placeholder="Search" ng-model="SenateSearch" />
                                                    </div>
                                                    <div class="table-responsive">


                                                        <table class="table">
                                                            <thead>
                                                                <tr>
                                                                    <th>Party</th>
                                                                    <th>Name</th>
                                                                    <th>Chamber</th>
                                                                    <th>District</th>
                                                                    <th>State</th>
                                                                    <th style="width:150px;"></th>
                                                                </tr>
                                                            </thead>
                                                            <tbody id="LegislatorsBody">

                                                                <tr dir-paginate="x in myData|filter:'Senate'|filter:SenateSearch|orderBy:'last_name'|itemsPerPage:10" pagination-id="LegisSenate">

                                                                    <td ng-switch on="x.party">
                                                                        <img src="R.png" ng-switch-when="R" width="25px" height="25px" />
                                                                        <img src="D.png" ng-switch-when="D" width="25px" height="25px" />
                                                                        <p ng-switch-when="I">I</p>
                                                                    </td>

                                                                    <td>{{x.last_name}},{{x.first_name}}</td>
                                                                    <td ng-switch on="x.chamber">
                                                                        <p ng-switch-when="house"><img src="h.png" width="25px" height="25px" /> House</p>
                                                                        <p ng-switch-when="senate"> <img src="s.svg" width="25px" height="25px" /> Senate</p>

                                                                    </td>
                                                                    <td ng-switch on="x.district">
                                                                        <p ng-switch-when="null">NA</p>
                                                                        <p ng-switch-default>District {{x.district}}</p>

                                                                    </td>
                                                                    <td>{{x.state_name}}</td>
                                                                    <td><a role="button" class="btn btn-primary" href="#myCarousel" data-slide="next" ng-click="GetLegisdetails(x.bioguide_id,'LegisDetailsStar')">View Details</a></td>


                                                                </tr>


                                                            </tbody>
                                                        </table>
                                                        <div class="text-center">
                                                            <dir-pagination-controls pagination-id="LegisSenate" max-size="10" direction-links="true" boundary-links="true">
                                                            </dir-pagination-controls>
                                                        </div>

                                                    </div>
                                                </div>

                                            </div>

                                        </div>
                                        <div class="LegislatorDetails item">
                                            <div class="page-header">
                                                <a class="btn btn-custom Detailsbtn" href="#myCarousel" role="button" data-slide="prev">
                                                    <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
                                                    <span class="sr-only">Next</span>
                                                </a>
                                                <h4 class="DetailsLabel">Details</h4>

                                                <button type="button" class="btn btn-custom" ng-click="FavLegis(LegisBio,'LegisDetailsStar')" style="float:right">
                                                <span class="glyphicon glyphicon-star" id="LegisDetailsStar" aria-hidden="true"></span>
                                                    
                                            </button>

                                            </div>
                                            <div class="LegisDetailsMainArea">
                                                <div class="modal-body row">
                                                    <div class="col-md-6 table-responsive">


                                                        <table class="table">
                                                            <tr></tr>
                                                            <tr>
                                                                <th rowspan="5" class="toChange toCenter"><img src="https://theunitedstates.io/images/congress/original/{{LegisBio}}.jpg" width="150px" height="170px"></th>
                                                                <th class="toChange">{{LegisName}}</th>
                                                            </tr>

                                                            <tr>
                                                                <th>
                                                                    <a href="mailto:{{LegisEmail}}">{{LegisEmail}}</a>
                                                                </th>
                                                            </tr>
                                                            <tr>
                                                                <th>Chamber:{{LegisChamber}}</th>
                                                            </tr>
                                                            <tr>
                                                                <th>Contact:<a href="tel:+{{LegisContact}}">
{{LegisContact}}</a></th>
                                                            </tr>
                                                            <tr>
                                                                <th ng-switch on="LegisParty">
                                                                    <p ng-switch-when="R"><img src="R.png" width="20px" height="20px" /> Republic</p>
                                                                    <p ng-switch-when="D"><img src="D.png" width="20px" height="20px" /> Democrat</p>
                                                                    <p ng-switch-when="I">Independent</p>
                                                                </th>

                                                            </tr>

                                                            <tr>
                                                                <th class="toHide">
                                                                    Start Term
                                                                </th>
                                                                <td>{{LegisStartTerm}}</td>
                                                            </tr>
                                                            <tr>
                                                                <th class="toHide">
                                                                    End Term
                                                                </th>
                                                                <td>{{LegisEndTerm}}</td>
                                                            </tr>
                                                            <tr>
                                                                <th class="toHide">
                                                                    Term
                                                                </th>
                                                                <td>
                                                                    <div class="progress">
                                                                        <div class="progress-bar progress-bar-success" role="progressbar" aria-valuenow="{{Legisterm}}" aria-valuemin="0" aria-valuemax="100" style="width:{{Legisterm}}%">
                                                                            <span>{{Legisterm | number:0}}%</span>
                                                                        </div>
                                                                    </div>
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <th class="toHide">
                                                                    Office
                                                                </th>
                                                                <td>{{LegisOffice}}</td>
                                                            </tr>
                                                            <tr>
                                                                <th class="toHide">
                                                                    State
                                                                </th>
                                                                <td>{{LegisState}}</td>
                                                            </tr>
                                                            <tr>
                                                                <th class="toHide">
                                                                    Fax
                                                                </th>
                                                                <td><a href="fax:+{{LegisFax}}">{{LegisFax}}</a>
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <th class="toHide">
                                                                    Birthday
                                                                </th>
                                                                <td>{{LegisBirthday}}</td>
                                                            </tr>
                                                            <tr>
                                                                <th class="toHide">
                                                                    Social Links
                                                                </th>
                                                                <td>
                                                                    <div style="float:left;padding-left:5px;" ng-switch on="Legistwitter">
                                                                        <p ng-switch-when="NA"></p>
                                                                        <a ng-switch-default href="{{Legistwitter}}" target="_blank"> <img src="t.png" width="25px" height="25px" /> </a>
                                                                    </div>

                                                                    <div style="float:left;padding-left:5px;" ng-switch on="Legisfb">
                                                                        <p ng-switch-when="NA"></p>
                                                                        <a ng-switch-default href="{{Legisfb}}" target="_blank"> <img src="f.png" width="25px" height="25px" /> </a>
                                                                    </div>
                                                                    <div style="float:left;padding-left:5px;" ng-switch on="Legisweb">
                                                                        <p ng-switch-when="NA"></p>
                                                                        <a ng-switch-default href="{{Legisweb}}" target="_blank"> <img src="w.png" width="25px" height="25px" /> </a>
                                                                    </div>
                                                                    <div style="float:clear;"></div>
                                                                </td>
                                                            </tr>

                                                        </table>
                                                    </div>
                                                    <div class="col-md-6 table-responsive">

                                                        <div class="Committees">
                                                            <table class="table">
                                                                <h4>Committees</h4>
                                                                <tr>
                                                                    <th>Chamber</th>
                                                                    <th>CommitteeID</th>
                                                                    <th class="toHide">Name</th>
                                                                </tr>
                                                                <tr ng-repeat="x in Committees|limitTo:5">
                                                                    <td>{{x.chamber}}</td>
                                                                    <td>{{x.committee_id}}</td>
                                                                    <td class="toHide">{{x.name}}</td>
                                                                </tr>
                                                            </table>
                                                        </div>
                                                        <div class="Bills">
                                                            <table class="table">
                                                                <h4>Bills</h4>
                                                                <tr>
                                                                    <th>BillID</th>
                                                                    <th class="toHide">Title</th>
                                                                    <th class="toHide">Chamber</th>
                                                                    <th class="toHide">Bill Type</th>
                                                                    <th class="toHide">Congress</th>
                                                                    <th>Link</th>
                                                                </tr>
                                                                <tr ng-repeat="x in Billsresponse|limitTo:5">
                                                                    <td>{{x.bill_id}}</td>
                                                                    <td class="toHide">{{x.official_title}}</td>
                                                                    <td class="toHide">{{x.chamber}}</td>
                                                                    <td class="toHide text-capitalize">{{x.bill_type}}</td>
                                                                    <td class="toHide">{{x.congress}}</td>
                                                                    <td><a ng-href="{{x.last_version.urls.pdf}}" target="_blank">Link</a></td>
                                                                </tr>
                                                            </table>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>



                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="BillsTab">
                            <h3 id="ContentHeading">Bills</h3>
                            <hr/>
                            <div class="MainDisplayArea">
                                <div id="myCarouselBills" class="carousel slide" data-ride="carousel" data-interval="false">
                                    <div class="carousel-inner" role="listbox">
                                        <div class="Listing item active">
                                            <ul class="nav nav-tabs">
                                                <li class="active"><a data-toggle="tab" href="#activeBills">Active Bills</a></li>
                                                <li><a data-toggle="tab" href="#billsNew">New Bills</a></li>

                                            </ul>
                                            <div class="tab-content">
                                                <div id="activeBills" class="tab-pane active">
                                                    <div class="well well-lg">

                                                        <h5><b>Active Bills</b></h5>
                                                        <input type="text" placeholder="Search" ng-model="ActiveSearch" />
                                                    </div>
                                                    <div class="table-responsive">


                                                        <table class="table">
                                                            <thead>
                                                                <tr>
                                                                    <th>Bill ID</th>
                                                                    <th>Bill Type</th>
                                                                    <th class="toHide">Title</th>
                                                                    <th>Chamber</th>
                                                                    <th>introduced On</th>
                                                                    <th>Sponsor</th>
                                                                    <th></th>
                                                                </tr>
                                                            </thead>
                                                            <tbody id="BillsBody">

                                                                <tr dir-paginate="x in myActiveBillsData|filter:ActiveSearch|orderBy:'-introduced_on'|itemsPerPage:10" pagination-id="BillsActive">

                                                                    <td>{{x.bill_id}}</td>
                                                                    <td class="text-capitalize">{{x.bill_type}}
                                                                    </td>
                                                                    <td class="toHide">{{x.official_title}}</td>
                                                                    <td ng-switch on="x.chamber">
                                                                        <p ng-switch-when="house"><img src="h.png" width="25px" height="25px" /> House</p>
                                                                        <p ng-switch-when="senate"> <img src="s.svg" width="25px" height="25px" /> Senate</p>

                                                                    </td>
                                                                    <td>{{x.introduced_on}}</td>
                                                                    <td>
                                                                        {{x.sponsor.first_name}}
                                                                    </td>
                                                                    <td><a role="button" class="btn btn-primary" href="#myCarouselBills" data-slide="next" ng-click="Billdetails(x.bill_id,'BillsFavStar')">View Details</a></td>

                                                                </tr>


                                                            </tbody>
                                                        </table>
                                                        <div class="text-center">
                                                            <dir-pagination-controls pagination-id="BillsActive" max-size="10" direction-links="true" boundary-links="true">
                                                            </dir-pagination-controls>
                                                        </div>

                                                    </div>
                                                </div>
                                                <div id="billsNew" class="tab-pane fade">
                                                    <div class="well well-lg">

                                                        <h5><b>New Bills</b></h5>
                                                        <input type="text" placeholder="Search" ng-model="NewSearch" />
                                                    </div>
                                                    <div class="table-responsive">


                                                        <table class="table">
                                                            <thead>
                                                                <tr>
                                                                    <th>Bill ID</th>
                                                                    <th>Bill Type</th>
                                                                    <th class="toHide">Title</th>
                                                                    <th>Chamber</th>
                                                                    <th>introduced On</th>
                                                                    <th>Sponsor</th>
                                                                    <th></th>
                                                                </tr>
                                                            </thead>
                                                            <tbody id="BillsBody">

                                                                <tr dir-paginate="x in myNewBillsData|filter:NewSearch|orderBy:'-introduced_on'|itemsPerPage:10" pagination-id="BillsNew">

                                                                    <td>{{x.bill_id}}</td>
                                                                    <td class="text-capitalize">{{x.bill_type}}
                                                                    </td>
                                                                    <td class="toHide">{{x.official_title}}</td>
                                                                    <td ng-switch on="x.chamber">
                                                                        <p ng-switch-when="house"><img src="h.png" width="25px" height="25px" /> House</p>
                                                                        <p ng-switch-when="senate"> <img src="s.svg" width="25px" height="25px" /> Senate</p>

                                                                    </td>
                                                                    <td>{{x.introduced_on}}</td>
                                                                    <td>
                                                                        {{x.sponsor.first_name}}
                                                                    </td>
                                                                    <td><a role="button" class="btn btn-primary" href="#myCarouselBills" data-slide="next" ng-click="Billdetails(x.bill_id,'BillsFavStar')">View Details</a></td>

                                                                </tr>


                                                            </tbody>
                                                        </table>
                                                        <div class="text-center">
                                                            <dir-pagination-controls pagination-id="BillsNew" max-size="10" direction-links="true" boundary-links="true">
                                                            </dir-pagination-controls>
                                                        </div>

                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="BillDetails item">
                                            <div class="page-header">
                                                <a class="btn btn-custom Detailsbtn" href="#myCarouselBills" role="button" data-slide="prev">
                                                    <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
                                                    <span class="sr-only">Prev</span>
                                                </a>
                                                <h4 class="DetailsLabel">Details</h4>
                                                <button type="button" class="btn btn-custom" ng-click="FavBills(BillID,'BillsFavStar')" style="float:right">
                                                <span class="glyphicon glyphicon-star" id="BillsFavStar" aria-hidden="true"></span>
                                            </button>

                                            </div>
                                            <div class="LegisDetailsMainArea">
                                                <div class="modal-body row">
                                                    <div class="col-md-6 table-responsive">
                                                        <table class="table">
                                                            <tr>
                                                                <th>
                                                                    BillID
                                                                </th>
                                                                <td>
                                                                    {{BillID}}
                                                                </td>
                                                            </tr>
                                                            <tr class="toHide">
                                                                <th>
                                                                    Title
                                                                </th>
                                                                <td>
                                                                    {{BillTitle}}
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <th>
                                                                    Bill Type
                                                                </th>
                                                                <td class="text-capitalize">
                                                                    {{BillType}}
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <th>
                                                                    Sponsor
                                                                </th>
                                                                <td>
                                                                    {{BillSponsor.title}}.{{BillSponsor.last_name}} {{BillSponsor.first_name}}
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <th>
                                                                    Chamber
                                                                </th>
                                                                <td>
                                                                    {{BillChamber}}
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <th>
                                                                    Status
                                                                </th>
                                                                <td>
                                                                    {{BillStatus}}
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <th>
                                                                    Introduced On
                                                                </th>
                                                                <td>
                                                                    {{BillIntro}}
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <th>
                                                                    Congress URL
                                                                </th>
                                                                <td><a ng-href="{{BillCongressUrl}}" target="_blank">Link</a></td>
                                                            </tr>
                                                            <tr>
                                                                <th>
                                                                    Version Status
                                                                </th>
                                                                <td>
                                                                    {{Billversion}}
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <th>
                                                                    Bill URL
                                                                </th>
                                                                <td><a ng-href="{{BillPDF}}" target="_blank">Link</a></td>
                                                            </tr>
                                                        </table>
                                                    </div>
                                                    <div class="col-md-6 table-responsive " style="height: 500px;overflow: hidden;">
                                                        <object data="{{BillPDF}}" type="application/pdf">
                                                    <embed src={{BillPDF}} type="application/pdf"/>
                                                    </object>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>
                        <div class="tab-pane fade" id="CommitteesTab">
                            <h3 id="ContentHeading">Committees</h3>
                            <hr/>
                            <div class="MainDisplayArea">
                                <div class="Listing item active">

                                    <ul class="nav nav-tabs">
                                        <li class="active"><a data-toggle="tab" href="#ComHouse">House</a></li>
                                        <li><a data-toggle="tab" href="#ComSenate">Senate</a></li>
                                        <li><a data-toggle="tab" href="#ComJoint">Joint</a></li>

                                    </ul>
                                </div>
                                <div class="tab-content">
                                    <div id="ComHouse" class="tab-pane fade in active">
                                        <div class="well well-lg">
                                            <h5><b>House</b></h5>
                                            <input type="text" placeholder="Search" ng-model="ComHouseSearch" />
                                        </div>
                                        <div class="table-responsive">


                                            <table class="table">
                                                <thead>
                                                    <tr>
                                                        <th></th>
                                                        <th>Chamber</th>
                                                        <th>Committee ID</th>
                                                        <th>Name</th>
                                                        <th>Parent Committee</th>
                                                        <th>Contact</th>
                                                        <th>Office</th>
                                                    </tr>
                                                </thead>
                                                <tbody id="ComBody">

                                                    <tr dir-paginate="x in myComData|filter: 'House'|filter:ComHouseSearch|orderBy:'committee_id'|itemsPerPage:10" pagination-id="CommHouse">
                                                        <td> <button type="button" class="btn btn-custom" ng-click="FavComm(x.committee_id)">
                                                <span class="glyphicon glyphicon-star" id="{{x.committee_id}}" aria-hidden="true"></span>
                                            </button></td>
                                                        <td ng-switch on="x.chamber">
                                                            <p ng-switch-when="house"><img src="h.png" width="25px" height="25px" /> House</p>
                                                            <p ng-switch-when="senate"> <img src="s.svg" width="25px" height="25px" /> Senate</p>

                                                        </td>
                                                        <td>{{x.committee_id}}</td>
                                                        <td>{{x.name}}</td>
                                                        <td>{{x.parent_committee_id}}</td>
                                                        <td>{{x.phone}}</td>
                                                        <td>{{x.office}}</td>



                                                    </tr>


                                                </tbody>
                                            </table>
                                            <div class="text-center">
                                                <dir-pagination-controls pagination-id="CommHouse" max-size="10" direction-links="true" boundary-links="true">
                                                </dir-pagination-controls>
                                            </div>

                                        </div>

                                    </div>
                                    <div id="ComSenate" class="tab-pane fade">
                                        <div class="well well-lg">
                                            <h5><b>Senate</b></h5>
                                            <input type="text" placeholder="Search" ng-model="ComSenSearch" />
                                        </div>
                                        <div class="table-responsive">


                                            <table class="table">
                                                <thead>
                                                    <tr>
                                                        <th></th>
                                                        <th>Chamber</th>
                                                        <th>Committee ID</th>
                                                        <th>Name</th>
                                                        <th>Parent Committee</th>

                                                    </tr>
                                                </thead>
                                                <tbody id="ComBody">

                                                    <tr dir-paginate="x in myComData|filter: 'senate'|filter:ComSenSearch|orderBy:'committee_id'|itemsPerPage:10" pagination-id="CommSenate">
                                                        <td> <button type="button" class="btn btn-custom" ng-click="FavComm(x.committee_id)">
                                                <span class="glyphicon glyphicon-star" id="{{x.committee_id}}" aria-hidden="true"></span>
                                            </button></td>
                                                        <td ng-switch on="x.chamber">
                                                            <p ng-switch-when="house"><img src="h.png" width="25px" height="25px" /> House</p>
                                                            <p ng-switch-when="senate"> <img src="s.svg" width="25px" height="25px" /> Senate</p>

                                                        </td>
                                                        <td>{{x.committee_id}}</td>
                                                        <td>{{x.name}}</td>
                                                        <td>{{x.parent_committee_id}}</td>




                                                    </tr>


                                                </tbody>
                                            </table>
                                            <div class="text-center">
                                                <dir-pagination-controls pagination-id="CommSenate" max-size="10" direction-links="true" boundary-links="true">
                                                </dir-pagination-controls>
                                            </div>

                                        </div>
                                    </div>
                                    <div id="ComJoint" class="tab-pane fade">
                                        <div class="well well-lg">
                                            <h5><b>Joint</b></h5>
                                            <input type="text" placeholder="Search" ng-model="ComJointSearch" />
                                        </div>
                                        <div class="table-responsive">


                                            <table class="table">
                                                <thead>
                                                    <tr>
                                                        <th></th>
                                                        <th>Chamber</th>
                                                        <th>Committee ID</th>
                                                        <th>Name</th>

                                                    </tr>
                                                </thead>
                                                <tbody id="ComBody">

                                                    <tr dir-paginate="x in myComData|filter: 'joint'|filter:ComJointSearch|orderBy:'committee_id'|itemsPerPage:10" pagination-id="CommJoint">
                                                        <td> <button type="button" class="btn btn-custom" ng-click="FavComm(x.committee_id)">
                                                <span class="glyphicon glyphicon-star" id="{{x.committee_id}}" aria-hidden="true"></span>
                                            </button></td>
                                                        <td>

                                                            <img src="s.svg" width="25px" height="25px" /> Joint

                                                        </td>
                                                        <td>{{x.committee_id}}</td>
                                                        <td>{{x.name}}</td>



                                                    </tr>


                                                </tbody>
                                            </table>
                                            <div class="text-center">
                                                <dir-pagination-controls pagination-id="CommJoint" max-size="10" direction-links="true" boundary-links="true">
                                                </dir-pagination-controls>
                                            </div>

                                        </div>
                                    </div>
                                </div>


                            </div>




                        </div>
                        <div class="tab-pane fade" id="FavsTab">

                            <h3 id="ContentHeading">Favorites</h3>
                            <hr/>
                            <div class="MainDisplayArea">

                                <ul class="nav nav-tabs">
                                    <li class="active"><a data-toggle="tab" href="#FavLegis">Legislators</a></li>
                                    <li><a data-toggle="tab" href="#FavBills">Bills</a></li>
                                    <li><a data-toggle="tab" href="#FavCom">Committees</a></li>

                                </ul>


                                <div class="tab-content">


                                    <div id="FavLegis" class="tab-pane fade in active">
                                        <div id="myFavLegisCarousel" class="carousel slide" data-ride="carousel" data-interval="false">
                                            <div class="carousel-inner" role="listbox">
                                                <div class="Listing item active">
                                                    <div class="well well-lg">

                                                        <h5><b>Favorite Legislators</b></h5>
                                                    </div>
                                                    <div class="table-responsive">


                                                        <table class="table">
                                                            <thead>
                                                                <tr>
                                                                    <th></th>
                                                                    <th>Image</th>
                                                                    <th>Party</th>
                                                                    <th>Name</th>
                                                                    <th>Chamber</th>
                                                                    <th>State</th>
                                                                    <th>Email</th>
                                                                    <th></th>
                                                                </tr>
                                                            </thead>
                                                            <tbody id="LegislatorsBody">

                                                                <tr ng-repeat="x in myFavLegisData">
                                                                    <td> <button type="button" class="btn btn-custom" ng-click="DelFavLegis($index)">
                                                <span class="glyphicon glyphicon-trash"  aria-hidden="true"></span>
                                                    
                                            </button></td>
                                                                    <td><img src="https://theunitedstates.io/images/congress/original/{{x.bioguide_id}}.jpg" width="20px" height="20px"></td>
                                                                    <td ng-switch on="x.party">
                                                                        <img src="R.png" ng-switch-when="R" width="25px" height="25px" />
                                                                        <img src="D.png" ng-switch-when="D" width="25px" height="25px" />
                                                                        <p ng-switch-when="I">I</p>
                                                                    </td>

                                                                    <td>{{x.last_name}},{{x.first_name}}</td>
                                                                    <td ng-switch on="x.chamber">
                                                                        <p ng-switch-when="house"><img src="h.png" width="25px" height="25px" /> House</p>
                                                                        <p ng-switch-when="senate"> <img src="s.svg" width="25px" height="25px" /> Senate</p>

                                                                    </td>

                                                                    <td>{{x.state_name}}</td>
                                                                    <td><a href="mailto:{{x.oc_email}}">{{x.oc_email}}</a></td>
                                                                    <td><a role="button" class="btn btn-primary" href="#myFavLegisCarousel" data-slide="next" ng-click="GetLegisdetails(x.bioguide_id,'LegisFavViewStar')">View Details</a></td>


                                                                </tr>


                                                            </tbody>
                                                        </table>


                                                    </div>
                                                </div>
                                                <div class="LegislatorFavDetails item">
                                                    <div class="page-header">
                                                        <a class="btn btn-custom Detailsbtn" href="#myFavLegisCarousel" role="button" data-slide="prev">
                                                            <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
                                                            <span class="sr-only">Next</span>
                                                        </a>
                                                        <h4 class="DetailsLabel">Details</h4>

                                                        <button type="button" class="btn btn-custom" ng-click="FavLegis(LegisBio,'LegisFavViewStar')" style="float:right">
                                                <span class="glyphicon glyphicon-star" id="LegisFavViewStar" aria-hidden="true"></span>
                                            </button>

                                                    </div>
                                                    <div class="LegisDetailsMainArea">
                                                        <div class="modal-body row">
                                                            <div class="col-md-6 table-responsive">


                                                                <table class="table">
                                                                    <tr></tr>
                                                                    <tr>
                                                                        <th rowspan="5"><img src="https://theunitedstates.io/images/congress/original/{{LegisBio}}.jpg" width="150px" height="170px"></th>
                                                                        <th>{{LegisName}}</th>
                                                                    </tr>

                                                                    <tr>
                                                                        <th>
                                                                            <a href="mailto:{{LegisEmail}}">{{LegisEmail}}</a>
                                                                        </th>
                                                                    </tr>
                                                                    <tr>
                                                                        <th>Chamber:{{LegisChamber}}</th>
                                                                    </tr>
                                                                    <tr>
                                                                        <th>Contact:{{LegisContact}}</th>
                                                                    </tr>
                                                                    <tr>
                                                                        <th ng-switch on="LegisParty">
                                                                            <p ng-switch-when="R"><img src="R.png" width="20px" height="20px" /> Republic</p>
                                                                            <p ng-switch-when="D"><img src="D.png" width="20px" height="20px" /> Democrat</p>
                                                                            <p ng-switch-when="I">Independent</p>
                                                                        </th>

                                                                    </tr>

                                                                    <tr>
                                                                        <th class="toHide">
                                                                            Start Term
                                                                        </th>
                                                                        <td>{{LegisStartTerm}}</td>
                                                                    </tr>
                                                                    <tr>
                                                                        <th class="toHide">
                                                                            End Term
                                                                        </th>
                                                                        <td>{{LegisEndTerm}}</td>
                                                                    </tr>
                                                                    <tr>
                                                                        <th class="toHide">
                                                                            Term
                                                                        </th>
                                                                        <td>
                                                                            <div class="progress">
                                                                                <div class="progress-bar progress-bar-success" role="progressbar" aria-valuenow="{{Legisterm}}" aria-valuemin="0" aria-valuemax="100" style="width:{{Legisterm}}%">
                                                                                    <span>{{Legisterm | number:0}}%</span>
                                                                                </div>
                                                                            </div>
                                                                        </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <th class="toHide">
                                                                            Office
                                                                        </th>
                                                                        <td>{{LegisOffice}}</td>
                                                                    </tr>
                                                                    <tr>
                                                                        <th class="toHide">
                                                                            State
                                                                        </th>
                                                                        <td>{{LegisState}}</td>
                                                                    </tr>
                                                                    <tr>
                                                                        <th class="toHide">
                                                                            Fax
                                                                        </th>
                                                                        <td>{{LegisFax}}</td>
                                                                    </tr>
                                                                    <tr>
                                                                        <th class="toHide">
                                                                            Birthday
                                                                        </th>
                                                                        <td>{{LegisBirthday}}</td>
                                                                    </tr>
                                                                    <tr>
                                                                        <th class="toHide">
                                                                            Social Links
                                                                        </th>
                                                                        <td>
                                                                            <div style="float:left;padding-left:5px;" ng-switch on="Legistwitter">
                                                                                <p ng-switch-when="NA"></p>
                                                                                <a ng-switch-default href="{{Legistwitter}}" target="_blank"> <img src="t.png" width="25px" height="25px" /> </a>
                                                                            </div>

                                                                            <div style="float:left;padding-left:5px;" ng-switch on="Legisfb">
                                                                                <p ng-switch-when="NA"></p>
                                                                                <a ng-switch-default href="{{Legisfb}}" target="_blank"> <img src="f.png" width="25px" height="25px" /> </a>
                                                                            </div>
                                                                            <div style="float:left;padding-left:5px;" ng-switch on="Legisweb">
                                                                                <p ng-switch-when="NA"></p>
                                                                                <a ng-switch-default href="{{Legisweb}}" target="_blank"> <img src="w.png" width="25px" height="25px" /> </a>
                                                                            </div>
                                                                            <div style="float:clear;"></div>
                                                                        </td>
                                                                    </tr>

                                                                </table>
                                                            </div>
                                                            <div class="col-md-6 table-responsive">

                                                                <div class="Committees">
                                                                    <table class="table">
                                                                        <h4>Committees</h4>
                                                                        <tr>
                                                                            <th>Chamber</th>
                                                                            <th>CommitteeID</th>
                                                                            <th class="toHide">Name</th>
                                                                        </tr>
                                                                        <tr ng-repeat="x in Committees|limitTo:5">
                                                                            <td>{{x.chamber}}</td>
                                                                            <td>{{x.committee_id}}</td>
                                                                            <td class="toHide">{{x.name}}</td>
                                                                        </tr>
                                                                    </table>
                                                                </div>
                                                                <div class="Bills">
                                                                    <table class="table">
                                                                        <h4>Bills</h4>
                                                                        <tr>
                                                                            <th>BillID</th>
                                                                            <th class="toHide">Title</th>
                                                                            <th class="toHide">Chamber</th>
                                                                            <th class="toHide">Bill Type</th>
                                                                            <th class="toHide">Congress</th>
                                                                            <th>Link</th>
                                                                        </tr>
                                                                        <tr ng-repeat="x in Billsresponse|limitTo:5">
                                                                            <td>{{x.bill_id}}</td>
                                                                            <td class="toHide">{{x.official_title}}</td>
                                                                            <td class="toHide">{{x.chamber}}</td>
                                                                            <td class="toHide text-capitalize">{{x.bill_type}}</td>
                                                                            <td class="toHide">{{x.congress}}</td>
                                                                            <td><a ng-href="{{x.last_version.urls.pdf}}" target="_blank">Link</a></td>
                                                                        </tr>
                                                                    </table>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>



                                                </div>
                                            </div>


                                        </div>
                                    </div>

                                    <div id="FavBills" class="tab-pane fade">
                                        <div id="myFavBillCarousel" class="carousel slide" data-ride="carousel" data-interval="false">
                                            <div class="carousel-inner" role="listbox">
                                                <div class="Listing item active">
                                                    <div class="well well-lg">

                                                        <h5><b>Favorite Bills</b></h5>

                                                    </div>
                                                    <div class="table-responsive">


                                                        <table class="table">
                                                            <thead>
                                                                <tr>
                                                                    <th></th>
                                                                    <th>Bill ID</th>
                                                                    <th>Bill Type</th>
                                                                    <th class="toHide">Title</th>
                                                                    <th>Chamber</th>
                                                                    <th>Introduced On</th>
                                                                    <th>Sponsor</th>
                                                                    <th></th>
                                                                </tr>
                                                            </thead>
                                                            <tbody id="BillsFavBody">

                                                                <tr ng-repeat="x in myFavBillData">
                                                                    <td><button type="button" class="btn btn-custom" ng-click="DelFavBill($index)">
                                                                        <span class="glyphicon glyphicon-trash"  aria-hidden="true"></span></button></td>
                                                                    <td>{{x.bill_id}}</td>
                                                                    <td class="text-capitalize">{{x.bill_type}}
                                                                    </td>
                                                                    <td class="toHide">{{x.official_title}}</td>
                                                                    <td ng-switch on="x.chamber">
                                                                        <p ng-switch-when="house"><img src="h.png" width="25px" height="25px" /> House</p>
                                                                        <p ng-switch-when="senate"> <img src="s.svg" width="25px" height="25px" /> Senate</p>

                                                                    </td>
                                                                    <td>{{x.introduced_on}}</td>
                                                                    <td>
                                                                        {{x.sponsor.first_name}}
                                                                    </td>
                                                                    <td><a role="button" class="btn btn-primary" href="#myFavBillCarousel" data-slide="next" ng-click="Billdetails(x.bill_id,'FavBillStar')">View Details</a></td>



                                                                </tr>


                                                            </tbody>
                                                        </table>


                                                    </div>
                                                </div>

                                                <div class="BillFavDetails item">
                                                    <div class="page-header">
                                                        <a class="btn btn-custom Detailsbtn" href="#myFavBillCarousel" role="button" data-slide="prev">
                                                            <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
                                                            <span class="sr-only">Prev</span>
                                                        </a>
                                                        <h4 class="DetailsLabel">Details</h4>
                                                        <button type="button" class="btn btn-custom" ng-click="FavBills(BillID,'FavBillStar')" style="float:right;">
                                                <span class="glyphicon glyphicon-star" id="FavBillStar" aria-hidden="true"></span>
                                            </button>

                                                    </div>
                                                    <div class="LegisDetailsMainArea">
                                                        <div class="modal-body row">
                                                            <div class="col-md-6 table-responsive">
                                                                <table>
                                                                    <tr>
                                                                        <th>
                                                                            BillID
                                                                        </th>
                                                                        <td>
                                                                            {{BillID}}
                                                                        </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <th class="toHide">
                                                                            Title
                                                                        </th>
                                                                        <td class="toHide">
                                                                            {{BillTitle}}
                                                                        </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <th>
                                                                            Bill Type
                                                                        </th>
                                                                        <td class="text-capitalize">
                                                                            {{BillType}}
                                                                        </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <th>
                                                                            Sponsor
                                                                        </th>
                                                                        <td>
                                                                            {{BillSponsor}}
                                                                        </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <th>
                                                                            Chamber
                                                                        </th>
                                                                        <td>
                                                                            {{BillChamber}}
                                                                        </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <th>
                                                                            Status
                                                                        </th>
                                                                        <td>
                                                                            {{BillStatus}}
                                                                        </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <th>
                                                                            Introduced On
                                                                        </th>
                                                                        <td>
                                                                            {{BillIntro}}
                                                                        </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <th>
                                                                            Congress URL
                                                                        </th>
                                                                        <td><a ng-href="{{BillCongressUrl}}" target="_blank">Link</a></td>
                                                                    </tr>
                                                                    <tr>
                                                                        <th>
                                                                            Version Status
                                                                        </th>
                                                                        <td>
                                                                            {{Billversion}}
                                                                        </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <th>
                                                                            Bill URL
                                                                        </th>
                                                                        <td><a ng-href="{{BillPDF}}" target="_blank">Link</a></td>
                                                                    </tr>
                                                                </table>
                                                            </div>
                                                            <div class="col-md-6 table-responsive">
                                                                <embed ng-src="{{content}}" />
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div id="FavCom" class="tab-pane fade">
                                        <div class="well well-lg">

                                            <h5><b>Favorite Committees</b></h5>

                                        </div>
                                        <div class="table-responsive">


                                            <table class="table">
                                                <thead>
                                                    <tr>
                                                        <th></th>
                                                        <th>Chamber</th>
                                                        <th>Committee ID</th>
                                                        <th>Name</th>
                                                        <th>Parent Committee</th>
                                                        <th>Sub Committee</th>

                                                    </tr>
                                                </thead>
                                                <tbody id="CommFavBody">

                                                    <tr ng-repeat="x in myFavCommData">
                                                        <td><button type="button" class="btn btn-custom" ng-click="FavComm(x.committee_id)">
                                                                        <span class="glyphicon glyphicon-trash"  aria-hidden="true"></span></button></td>
                                                        <td ng-switch on="x.chamber">
                                                            <p ng-switch-when="house"><img src="h.png" width="25px" height="25px" /> House</p>
                                                            <p ng-switch-when="senate"> <img src="s.svg" width="25px" height="25px" /> Senate</p>

                                                        </td>
                                                        <td>{{x.committee_id}}</td>
                                                        <td>{{x.name}}</td>
                                                        <td>{{x.parent_committee_id}}</td>
                                                        <td>{{x.subcommittee}}</td>


                                                    </tr>


                                                </tbody>
                                            </table>


                                        </div>
                                    </div>

                                </div>

                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>

</html>
